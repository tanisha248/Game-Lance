
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyAVV6kSFPJvaqcvwEB5p1XoTquaqUYTwbU",
  authDomain: "gamelance-70b97.firebaseapp.com",
  projectId: "gamelance-70b97",
  storageBucket: "gamelance-70b97.firebasestorage.app",
  messagingSenderId: "55936519076",
  appId: "1:55936519076:web:fba7a66d6cd97331bb0f31",
  measurementId: "G-B5RTBK1LVL"
};


const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const googleProvider = new  GoogleAuthProvider();
export const storage = getStorage(app);