import { createUserWithEmailAndPassword } from "firebase/auth";
import { useEffect, useState } from "react";
import { auth, db } from "../Firebase";
import { collection, doc, getDocs, onSnapshot, setDoc, Timestamp, updateDoc } from "firebase/firestore";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import Loader from "../User/Loader";

export default function CompletedOrders() {
  const [data, setData] = useState([]);
  
  const [attachmentInputs, setAttachmentInputs] = useState({});
     const[load,setLoad]=useState(false);
    const[display,setDisplay] = useState("block")
  const nav = useNavigate();

  useEffect(() => {
    getOrder();
  }, []);

  const getOrder = async () => {
    setLoad(true)
    setDisplay("none")
    try {
      const categoryCollection = collection(db, "categories");
      const orderCollection = collection(db, "orders");
      const userCollection = collection(db, "users");

      const [categoriesData, ordersData, usersData] = await Promise.all([
        getDocs(categoryCollection),
        getDocs(orderCollection),
        getDocs(userCollection),
      ]);

      const categories = categoriesData.docs.map(doc => ({ ...doc.data(), id: doc.id }));
      const users = usersData.docs.map(doc => ({ ...doc.data(), id: doc.id }));
      const orders = ordersData.docs.map(doc => ({ ...doc.data(), id: doc.id }));

      const joinedData = orders.map(order => {
        const category = categories.find(cat => cat.id === order.categoryId);
        const user = users.find(u => u.id === order.userId);
        return {
          ...order,
          category,
          user,
        };
      });

      const acceptedOrders = joinedData.filter(order => order.status === "Completed");
      setData(acceptedOrders);
    } catch (error) {
      console.error("Error fetching orders:", error);
    }
    setDisplay("block")
    setLoad(false)
  };

  
  

  const handleFileChange = (orderId, event) => {
    const file = event.target.files[0];
    setAttachmentInputs(prev => ({ ...prev, [orderId]: file }));
  };

  const handleFinalAttachment = async (orderId) => {
    setLoad(true);
    setDisplay("none")
    try {
      const finalAttachment = attachmentInputs[orderId];
      if (!finalAttachment) {
        toast.error("Please upload an attachment.", { position: "top-center" });
        return;
      }

      // Cloudinary raw file upload
      const formData = new FormData();
      formData.append("file", finalAttachment);
      formData.append("upload_preset", "gamelance_upload"); // replace with your preset
      formData.append("resource_type", "raw");

      const cloudName = "dw63rvf8n"; // your Cloudinary cloud name
      const res = await axios.post(
        `https://api.cloudinary.com/v1_1/${cloudName}/raw/upload`,
        formData
      );

      const attachmentUrl = res.data.secure_url;

      const orderDocRef = doc(db, "orders", orderId);
      await updateDoc(orderDocRef, { attachmentUrl });

      toast.success("Attachment saved successfully!", { position: "top-center" });

      setData(prevData =>
        prevData.map(order =>
          order.id === orderId ? { ...order, attachmentUrl } : order
        )
      );

      setTimeout(() => {
        setLoad(false);
        setDisplay("block")
      }, 2000);
    } catch (error) {
      console.error("Error saving attachment:", error);
      toast.error("Failed to save attachment.", { position: "top-center" });
      setTimeout(() => {
         setLoad(false);
        setDisplay("block")
      }, 2000);
    }
  };

  return (
    <>
      <section className="page-info-section set-bg" style={{ backgroundImage: "url('/img/page-top-bg/5.jpg')" }}>
        <div className="pi-content">
          <div className="container">
            <div className="row">
              <div className="col-xl-5 col-lg-6 text-white">
                <h2>Order</h2>
              </div>
            </div>
          </div>
        </div>
      </section>
    {load?<Loader />:null}
      <section className="page-section spad contact-page" style={{display:display}}>
        <div className="container">
          <div className="row justify-content-end">
            <div className="col-2 mb-5">
              <Link to={'/admin/pendingorders'}><button className="btn btn-outline-primary">⏳ Pending Orders</button></Link>
            </div>
            <div className="col-2 mb-5">
              <Link to={'/admin/rejectedorders'}><button className="btn btn-outline-danger">🚫 Rejected Orders</button></Link>
            </div>
            <div className="col-2 mb-5">
              <Link to={'/admin/acceptedorders'}><button className="btn btn-outline-success">✅ Accepted Orders</button></Link>
            </div>
            <div className="col-2 mb-5">
              <Link to={'/admin/canceledorders'}><button className="btn btn-outline-warning">❌ Canceled Orders</button></Link>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-12 p-5" style={{ border: "3px solid black", backgroundColor: "black" }}>
              <div className="contact-form-warp table-responsive">
                <h3 className="comment-title text-center text-light">COMPLETED ORDERS</h3>
                <table className="table text-light table-bordered">
                  <thead>
                    <tr>
                      <th>Sr No.</th>
                      <th>User Info.</th>
                      <th>Game Name</th>
                      <th>Category</th>
                      <th>Budget</th>
                      <th>Deadline</th>
                      <th>Platforms</th>
                      <th>Final Attachment</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.map((el, index) => (
                      <tr key={el.id}>
                        <th scope="row">{index + 1}</th>
                        <td>
                          <ul type="none">
                            <li><span className="text-success">Name: </span>{el?.user?.name}</li>
                            <li><span className="text-success">Email: </span>{el?.user?.email}</li>
                            <li><span className="text-success">Contact: </span>{el?.user?.contact}</li>
                            <li><span className="text-success">Address: </span>{el?.user?.address}</li>
                          </ul>
                        </td>
                        <td>{el.gameName}</td>
                        <td>{el?.category?.categoryName}</td>
                        <td>{el.budget}</td>
                        <td>{el.deadline}</td>
                        <td>{el.platform}</td>
                        <td>
                          {el.attachmentUrl ? (
                            <button className="btn btn-primary mt-2" onClick={() => window.open(el.attachmentUrl, "_blank")}>
                              View Final Attachment
                            </button>
                          ) : (
                            <>
                              <input
                                type="file"
                                className="form-control mb-2"
                                onChange={(e) => handleFileChange(el.id, e)}
                              />
                              <button
                                className="btn btn-primary"
                                onClick={() => handleFinalAttachment(el.id)}
                              >
                                Save Attachment
                              </button>
                            </>
                          )}
                        </td>
                        <td>{el.status}</td>
                        
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
