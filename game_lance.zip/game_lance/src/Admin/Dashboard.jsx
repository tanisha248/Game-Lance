import { collection, getDocs } from "firebase/firestore";
import { useEffect, useState } from "react";
import { db } from "../Firebase";
import Loader from "../User/Loader";

export default function Dashboard(){
  const [userCount, setUserCount] = useState(0);
  const [orderCount, setOrderCount] = useState(0);
  const [categoryCount, setCategoryCount] = useState(0);
  const [gameCount, setGameCount] = useState(0);
  const[load,setLoad]=useState(false);
  const[display,setDisplay] = useState("block")

 
  useEffect(() => {
    setLoad(true)
    setDisplay("none")
    const fetchCounts = async () => {
      try {
        const usersSnapshot = await getDocs(collection(db, 'users'));
        setUserCount(usersSnapshot.size);

        const orderSnapshot = await getDocs(collection(db, 'orders'));
        setOrderCount(orderSnapshot.size);

        const categorySnapshot = await getDocs(collection(db, 'categories'));
        setCategoryCount(categorySnapshot.size);

        const gameSnapshot = await getDocs(collection(db, 'games'));
        setGameCount(gameSnapshot.size);
      } catch (error) {
        console.error("Error fetching document counts: ", error);
      }
    };

    fetchCounts();
   setTimeout(() => {
     setDisplay("block")
    setLoad(false)
   }, 700);
  }, []);
    return(
        <>
        <>
  {/* Page info section */}
  {load?<Loader />:null}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('img/page-top-bg/1.jpg')",display:display}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>WELCOME ADMIN</h2>
            
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
   {/* Stats section */}
      <section className="page-section recent-game-page spad" style={{ padding: "50px 0",display:display }}>
        <div className="container">
          <div className="row text-center">
            
            <div className="col-md-3 mb-4">
              <div style={{ background: "#f8f9fa",border:"3px solid deeppink", borderRadius: "10px", padding: "30px" }}>
                <div style={{ fontSize: "50px" }}>📦</div>
                <h5 className="mt-3">Total Categories</h5>
                <p style={{ fontSize: "24px", margin: 0 }}>{categoryCount}</p>
              </div>
            </div>

            <div className="col-md-3 mb-4">
              <div style={{ background: "#f8f9fa",border:"3px solid green", borderRadius: "10px", padding: "30px" }}>
                <div style={{ fontSize: "50px" }}>🎮</div>
                <h5 className="mt-3">Total Games</h5>
                <p style={{ fontSize: "24px", margin: 0 }}>{gameCount}</p>
              </div>
            </div>

            <div className="col-md-3 mb-4">
              <div style={{ background: "#f8f9fa",border:"3px solid orange", borderRadius: "10px", padding: "30px" }}>
                <div style={{ fontSize: "50px" }}>👥</div>
                <h5 className="mt-3">Total Users</h5>
                <p style={{ fontSize: "24px", margin: 0 }}>{userCount}</p>
              </div>
            </div>

            <div className="col-md-3 mb-4">
              <div style={{ background: "#f8f9fa",border:"3px solid dodgerblue", borderRadius: "10px", padding: "30px" }}>
                <div style={{ fontSize: "50px" }}>🛒</div>
                <h5 className="mt-3">Total Orders</h5>
                <p style={{ fontSize: "24px", margin: 0 }}>{orderCount}</p>
              </div>
            </div>

          </div>
        </div>
      </section>
  {/* Page section end */}
  
</>

        </>
    )
}