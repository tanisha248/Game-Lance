import { createUserWithEmailAndPassword } from "firebase/auth";
import { useEffect, useState } from "react"
import { auth, db } from "../Firebase";
import { collection, doc, getDocs, onSnapshot, setDoc, Timestamp, updateDoc } from "firebase/firestore";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import Loader from "../User/Loader";

export default function RejectedOrders(){
  
    const [data, setData] = useState([]);
    const[load,setLoad]=useState(false);
   const nav = useNavigate();
    const[display,setDisplay] = useState("block")
    useEffect(()=>{
      getOrder()
    },[])

    const getOrder = async () => {
      setLoad(true)
      setDisplay("none")
  try {
    const categoryCollection = collection(db, "categories");
    const orderCollection = collection(db, "orders");
    const userCollection = collection(db, "users");

    const [categoriesData, ordersData, usersData] = await Promise.all([
      getDocs(categoryCollection),
      getDocs(orderCollection),
      getDocs(userCollection),
    ]);

    const categories = categoriesData.docs.map(doc => ({ ...doc.data(), id: doc.id }));
    const users = usersData.docs.map(doc => ({ ...doc.data(), id: doc.id }));
    const orders = ordersData.docs.map(doc => ({ ...doc.data(), id: doc.id }));

    const joinedData = orders.map(order => {
      const category = categories.find(cat => cat.id === order.categoryId);
      const user = users.find(u => u.id === order.userId);
      return {
        ...order,
        category,
        user,
      };
    });

   const pendingOrders = joinedData.filter(order => order.status === "Rejected");
                        setData(pendingOrders);
    
  } catch (error) {
    console.error("Error fetching orders:", error);
  }
  setDisplay("block")
  setLoad(false)
};

const approveOrder = async (orderId) => {
   setLoad(true)
      setDisplay("none")
        try {
            const orderDocRef = doc(db, "orders", orderId);
            await updateDoc(orderDocRef, { status: "Accepted" });
            toast.success("Order Approved successfully!");
            setTimeout(() => {
                nav("/admin/acepptedorders")
            }, 2000);
        } catch (error) {
            console.error("Error approving order:", error);
            toast.error("Failed to approving the order.");
        }
    };

    const rejectOrder = async (orderId) => {
        try {
            const orderDocRef = doc(db, "orders", orderId);
            await updateDoc(orderDocRef, { status: "Rejected" });
            toast.success("Order Rejected successfully!");
            setTimeout(() => {
                nav("/admin/rejectedorders")
            }, 2000);
        } catch (error) {
            console.error("Error rejecting order:", error);
            toast.error("Failed to reject the order.");
        }
         setLoad(false)
      setDisplay("block")
    };



    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('/img/page-top-bg/5.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>Order</h2>
           
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
  {load?<Loader />:null}
  <section className="page-section spad contact-page" style={{display:display}}>
    <div className="container">
     <div className="row justify-content-end">
        <div className="col-2 mb-5">
      <Link to={'/admin/pendingorders'}><button className="btn btn-outline-info">⏳ Pending Orders</button></Link>
      </div>
      <div className="col-2 mb-5">
      <Link to={'/admin/acceptedorders'}><button className="btn btn-outline-primary">✅ Accepted Orders</button></Link>
      </div>
      <div className="col-2 mb-5">
      <Link to={'/admin/completedorders'}><button className="btn btn-outline-success">🎉 Completed Orders</button></Link>
      </div>
      <div className="col-2 mb-5">
      <Link to={'/admin/canceledorders'}><button className="btn btn-outline-warning">❌ Canceled Orders</button></Link>
      </div>
     </div>
      <div className="row">
        <div className="col-lg-12 p-5" style={{border:"3px solid black",backgroundColor:"black"}}>
          <div className="contact-form-warp table-responsive">
            <h3 className="comment-title text-center text-light">REJECTED ORDERS</h3>
           <table class="table text-light table-bordered">
            <thead>
                <tr>
                <th scope="col">Sr No.</th>
                <th scope="col">User Info.</th>
                <th scope="col">Game Name</th>
                <th scope="col">Category</th>
                <th scope="col">Budget</th>
                <th scope="col">Deadline</th>
                <th scope="col">Platforms</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
               {data.map((el, index) => (
                                    <tr key={el.id}>
                                    <th scope="row">{index + 1}</th>
                                    <td>
                                      <ul type="none">
                                        <li><span className="text-success">Name: </span>{el?.user?.name}</li>
                                        <li><span className="text-success">Email: </span>{el?.user?.email}</li>
                                        <li><span className="text-success">Contact: </span>{el?.user?.contact}</li>
                                        <li><span className="text-success">Address: </span>{el?.user?.address}</li>
                                      </ul>
                                    </td>
                                            <td>{el.gameName}</td>
                                           <td>{el?.category?.categoryName}</td>
                                            <td>{el.budget}</td>
                                            <td>{el.deadline}</td>
                                            <td>{el.platform}</td>
                                            <td>
                                            {el.status}
                                            </td>
                                            
                                            <td>
                                                <button
                                                    className="btn btn-success" style={{marginRight:"5px"}}
                                                    onClick={() => approveOrder(el.id)}
                                                >
                                                    Accept
                                                </button>
                                                <button
                                                    className="btn btn-danger"
                                                    onClick={() => rejectOrder(el.id)}
                                                >
                                                    Reject
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
            </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page section end */}
</>

        </>
    )
}