import { createUserWithEmailAndPassword, getAuth } from "firebase/auth";
import { useEffect, useState } from "react"
import { auth, db } from "../Firebase";
import { addDoc, collection, doc, getDocs, query, setDoc, Timestamp, where } from "firebase/firestore";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import Loader from "../User/Loader";

export default function AddCategory(){
  const[categoryName,setCategoryName]=useState("");
  const[image,setImage]=useState("");
  const nav = useNavigate();
   const[load,setLoad]=useState(false);
   const[display,setDisplay] = useState("block")

useEffect(() =>{
  setLoad(true)
  setDisplay("none")

  setTimeout(() => {
    setLoad(false)
    setDisplay("block")
  }, 700);
},[])


   const addCategories = async (e) => {
       e.preventDefault();
        setLoad(true);
        setDisplay("none")
       if (categoryName === "" ||  !image) {
           toast.error("All Fields are mandatory", {
               position: "top-center",
           });
           setLoad(false);
           setDisplay("block")
           return;
       }

       try {
           const auth = getAuth();
           const user = auth.currentUser;

           if (!user) {
               toast.error("Admin is not authenticated", {
                   position: "top-center"
               });
               setLoad(false);
               setDisplay("block")
               return;
           }

           const categoryRef = collection(db, "categories");

           
           const q = query(categoryRef, where("categoryName", "==", categoryName));
           const querySnapshot = await getDocs(q);

           if (!querySnapshot.empty) {
               toast.error("category name already exists", {
                   position: "top-center",
               });
               setLoad(false);
               setDisplay("block")
               return; 
           }

            // --- CLOUDINARY IMAGE UPLOAD START ---
           const formData = new FormData();
           formData.append("file", image);
           formData.append("upload_preset", "gamelance_upload"); // Replace with your Cloudinary preset

           const cloudName = "dw63rvf8n"; // Replace with your Cloudinary cloud name

           const res = await axios.post(
               `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`,
               formData
           );

           const imageUrl = res.data.secure_url;
           // --- CLOUDINARY IMAGE UPLOAD END ---

           const newcategory = {
               categoryName,
               imageUrl,
               userId: user.uid,
               status: "active",
               created_at: Timestamp.now(),
           };

           await addDoc(categoryRef, newcategory);
           toast.success("Data Added successfully", {
               position: "top-center",
           });
           setLoad(false);
           setDisplay("block")
          
               nav("/admin/managecategories");
           
       } catch (error) {
           toast.error("Something Went Wrong", {
               position: "top-center"
           });
          setLoad(false);
          setDisplay("block")
           console.log(error);
       }
   };


    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('/img/page-top-bg/5.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>Categories</h2>
           
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
 
 {load?<Loader />:null}
  <section className="page-section spad contact-page" style={{display:display}}>
    <div className="container">
     <div className="row justify-content-end">
      <div className="col-3 mb-5">
      <Link to={'/admin/managecategories'}><button className="btn btn-outline-warning">📋 Manage Categories</button></Link>
      </div>
     </div>
      <div className="row">
        <div className="col-lg-12 p-5" style={{border:"3px solid black",backgroundColor:"black"}}>
          <div className="contact-form-warp">
            <h3 className="comment-title text-center text-light">ADD CATEGORIES</h3>
            <form className="comment-form" onSubmit={addCategories}>
              <div className="row">
                <div className="col-md-6">
                    <label className="text-light">Enter Category Name:</label>
                  <input type="text"
                  value={categoryName}
                  onChange={(e)=>setCategoryName(e.target.value)}
                  className="form-control" placeholder="Name" />
                </div>
                <div className="col-md-6">
                     <label className="text-light">Upload Image:</label>
                  <input type="file" 
                  onChange={(e) => setImage(e.target.files[0])}
                  className="form-control" placeholder="Email" />
                </div>
                
               
                <div className="col-lg-12">
                  <button className="site-btn btn-lg w-50 offset-md-3">Save</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page section end */}
</>

        </>
    )
}