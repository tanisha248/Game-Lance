import { createUserWithEmailAndPassword, getAuth } from "firebase/auth";
import { useEffect, useState } from "react"
import { auth, db } from "../Firebase";
import { addDoc, collection, doc, getDoc, getDocs, onSnapshot, query, setDoc, Timestamp, updateDoc, where } from "firebase/firestore";
import { toast } from "react-toastify";
import { Link, useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import Loader from "../User/Loader";

export default function UpdateGames(){
  const[gameName,setGameName]=useState("");
  const[image,setImage]=useState("");
  const[description,setDescription]=useState("");
  const[categoryId,setCategoryId]=useState("");
  const[existingImageUrl,setExistingImageUrl]=useState("");
  const[previewUrl,setPreviewUrl]=useState("");
  const nav = useNavigate();
  const[load,setLoad]=useState(false);
  const[display,setDisplay] = useState("block")
  const [data, setData] = useState([]);
  const { id } = useParams(); 

//    setTimeout(() => {
//     setLoad(false);
//    }, 2000);

useEffect(() => {

          setLoad(true)
          setDisplay("none")
           const getCategories = () => {
               const categoryRef = collection(db, "categories");
   
               const unsubscribe = onSnapshot(categoryRef, (snapshot) => {
                   const Categories = snapshot.docs.map(doc => ({
                       id: doc.id,
                       ...doc.data()
                   }));
                   setData(Categories);
               });
   
               return () => unsubscribe();
           };
   
           getCategories();
           setTimeout(() => {
            setLoad(false)
            setDisplay("block")
           }, 700);
       }, []);

       useEffect(() => {
               const fetchGameData = async () => {
                   try {
                       const docRef = doc(db, "games", id);
                       const docSnap = await getDoc(docRef);
       
                       if (docSnap.exists()) {
                           const GameData = docSnap.data();
                           setGameName(GameData.gameName);
                           setCategoryId(GameData.categoryId);
                           setDescription(GameData.description)
                           setExistingImageUrl(GameData.imageUrl);
                       } else {
                           toast.error("Game type not found", { position: "top-center" });
                       }
                   } catch (error) {
                       toast.error("Failed to fetch Game data", { position: "top-center" });
                       console.error("Error fetching Game data: ", error);
                   }
               };
       
               fetchGameData();
           }, [id]);

   const updateGames = async (e) => {
       e.preventDefault();
        setLoad(true);
       setDisplay("none")
       try {
           const auth = getAuth();
           const user = auth.currentUser;

           if (!user) {
               toast.error("Admin is not authenticated", {
                   position: "top-center"
               });
               setLoad(false);
               setDisplay("block")
               return;
           }

           const gameRef = collection(db, "games");

           
          const q = query(gameRef, where("gameName", "==", gameName));
                    const querySnapshot = await getDocs(q);

                    let isDuplicate = false;

                    querySnapshot.forEach(doc => {
                        if (doc.id !== id) {
                            isDuplicate = true;
                        }
                    });

                    if (isDuplicate) {
                        toast.error("Game name already exists", {
                            position: "top-center",
                        });
                        setLoad(false);
                          setDisplay("block")
                    return;
                }


           let imageUrl = existingImageUrl;

            if (image) {
              const formData = new FormData();
              formData.append("file", image);
              formData.append("upload_preset", "gamelance_upload");

              const cloudName = "dw63rvf8n";

              const res = await axios.post(
                `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`,
                formData
              );

              
              imageUrl = res.data.secure_url;
            }


           const docRef = doc(db, "games", id);
            await updateDoc(docRef, {
                gameName,
                imageUrl,
                description,
                categoryId,
                userId: user.uid,
                status: "active",
                updated_at: Timestamp.now(),
            });
           toast.success("Data Updated successfully", {
               position: "top-center",
           });
           setLoad(false);
             setDisplay("block")
          
               nav("/admin/manageGames");
          
       } catch (error) {
           toast.error("Something Went Wrong", {
               position: "top-center"
           });
          setLoad(false);
            setDisplay("block");
           console.log(error);
       }
   };


    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('/img/page-top-bg/5.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>Games</h2>
           
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
  {load?<Loader />:null}
  <section className="page-section spad contact-page" style={{display:display}}>
    <div className="container">
     <div className="row justify-content-end">
      <div className="col-3 mb-5">
      <Link to={'/admin/managegames'}><button className="btn btn-warning">Manage Games</button></Link>
      </div>
     </div>
      <div className="row">
        <div className="col-lg-12 p-5" style={{border:"3px solid black",backgroundColor:"black"}}>
          <div className="contact-form-warp">
            <h3 className="comment-title text-center text-light">UPDATE GAME</h3>
            <form className="comment-form" onSubmit={updateGames}>
              <div className="row">
                <div className="col-md-6">
                    <label className="text-light">Enter Game Name:</label>
                  <input type="text"
                  value={gameName}
                  onChange={(e)=>setGameName(e.target.value)}
                  className="form-control" placeholder="Game Name" />
                </div>
                <div className="col-md-6">
                    <label className="text-light">Select Category:</label>
                  <select type="text"
                  value={categoryId}
                  onChange={(e)=>setCategoryId(e.target.value)}
                  className="form-control" placeholder="Name" >
                    <option>Select Category</option>
                    {data?.map((el,index)=>(
                      <>
                      <option value={el.id}>{el.categoryName}</option>
                      </>
                    ))}
                  </select>
                </div>
                    <div className="col-md-12 mb-3">
                {existingImageUrl && !image && (
                <img src={existingImageUrl} className="w-50" alt="Existing Property" height={200} style={{ marginTop: '10px', maxWidth: '100%' }} />
                )}
                </div>
                {previewUrl && (
              <div className="col-md-12 mt-3">
                <label className="text-light">Updated Image Preview:</label>
                <img
                className="offset-md-1"
                  src={previewUrl}
                  alt="Updated Preview"
                  height={200}
                  style={{ maxWidth: "100%", border: "2px dashed white", marginTop: "10px" }}
                />
              </div>
            )}

                <div className="col-md-12">
                     <label className="text-light">Upload Image:</label>
                  <input
                  type="file"
                  onChange={(e) => {
                    const file = e.target.files[0];
                    setImage(file);
                    if (file) {
                      setPreviewUrl(URL.createObjectURL(file));
                    }
                  }}
                  className="form-control"
                  placeholder="Upload Image"
                />
                </div>
                 
                <div className="col-md-12 mt-3">
                    <label className="text-light">Enter Description:</label>
                  <textarea 
                  value={description}
                  onChange={(e)=>setDescription(e.target.value)}
                  className="form-control" placeholder="Description" />
                </div>

                <div className="col-lg-12">
                  <button className="site-btn btn-lg w-50 offset-md-3">Save</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page section end */}
</>

        </>
    )
}