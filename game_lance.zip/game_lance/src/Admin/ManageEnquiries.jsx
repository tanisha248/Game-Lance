import { createUserWithEmailAndPassword } from "firebase/auth";
import { useEffect, useState } from "react"
import { auth, db } from "../Firebase";
import { collection, deleteDoc, doc, onSnapshot, setDoc, Timestamp } from "firebase/firestore";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import Loader from "../User/Loader";

export default function ManageEnquiries(){
  
    const [data, setData] = useState([]);
    const[load,setLoad]=useState(false);
    const[display,setDisplay] = useState("block")
    // setTimeout(() => {
    //     setLoad(false);
    // }, 1000);

    useEffect(() => {
      setLoad(true)
      setDisplay("none")
        const getEnquiries = () => {
            const categoryRef = collection(db, "queries");

            const unsubscribe = onSnapshot(categoryRef, (snapshot) => {
                const Enquiries = snapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data()
                }));
                setData(Enquiries);
            });

            return () => unsubscribe();
        };

        getEnquiries();
        setTimeout(() =>{ 
          setLoad(false)
        setDisplay("block")
        },1000)
    }, []);

   
     const handleReply = (email, subject, message) => {
        const gmailURL = `https://mail.google.com/mail/?view=cm&fs=1&to=${email}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(message)}`;
        window.open(gmailURL, '_blank');
    };
    

    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('/img/page-top-bg/5.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>Enquiries</h2>
           
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
  {load?<Loader />:null}
  <section className="page-section spad contact-page" style={{display:display}}>
    <div className="container">
      <div className="row">
        <div className="col-lg-12 p-5" style={{border:"3px solid black",backgroundColor:"black"}}>
          <div className="contact-form-warp">
            <h3 className="comment-title text-center text-light">MANAGE ENQUIRIES</h3>
           <table class="table text-light table-bordered">
            <thead>
                <tr>
                <th scope="col">Sr No.</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Subject</th>
                <th scope="col">Message</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
               {data.map((el, index) => (
                                    <tr key={el.id}>
                                    <th scope="row">{index + 1}</th>
                                            <td>{el.name}</td>
                                            <td>{el.email}</td>
                                            <td>{el.subject}</td>
                                           <td>{el.message}</td>
                                            <td>
                                             <button
                                                        className="btn btn-success btn-lg"
                                                        onClick={() => handleReply(el?.email, el?.subject, el?.message)}
                                                    >
                                                        Reply
                                                    </button>
                                            </td>
                                        </tr>
                                    ))}
            </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page section end */}
</>

        </>
    )
}