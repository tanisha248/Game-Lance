import { createUserWithEmailAndPassword } from "firebase/auth";
import { useEffect, useState } from "react"
import { auth, db } from "../Firebase";
import { collection, doc, getDocs, onSnapshot, setDoc, Timestamp } from "firebase/firestore";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import Loader from "../User/Loader";

export default function ManageGames(){
  
    const [data, setData] = useState([]);
    const[load,setLoad]=useState(false);
    const[display,setDisplay] = useState("block")
    
    useEffect(()=>{
      setLoad(true)
      setDisplay("none")
        getGames();

        
    },[])
    const getGames = async () => {
        try {
            const categoryCollection = collection(db,"categories")
            const gameCollection = collection(db,"games")

            const categoriesData = await getDocs(categoryCollection);
            const gamesData = await getDocs(gameCollection);
    
            const categories = categoriesData.docs.map(doc => ({ ...doc.data(), id: doc.id }));
            console.log("categories are:",categories)
            const games = gamesData.docs.map(doc => ({ ...doc.data(), id: doc.id }));
    
            const joinedData = games.map(gameData => {
                const categoryData = categories.find(category => category.id === gameData.categoryId);
                return {
                    ...gameData,
                    category: categoryData
                };
            });
             setLoad(false)
          setDisplay("block")
            setData(joinedData);
            console.log(joinedData)
        } catch (error) {
            console.error("Error fetching bookings:", error);
             setLoad(false)
          setDisplay("block")
        }
    };
const handleDelete = async (id) => {
    setLoad(true);
    setDisplay("none")
    try {
      const gamesDoc = doc(db, "games", id);
      await deleteDoc(gamesDoc);
      toast.success("Data Deleted Successfully")
      setTimeout(() => {
        setLoad(false);
        setDisplay("block")
      }, 2000);
      setData(prevData => prevData.filter(games => games.id !== id));
    } catch (error) {
      toast.error("Something went wrong", {
        position: "top-center"
      })
      setTimeout(() => {
        setLoad(false);
        setDisplay("block")
      }, 2000);
      console.error("Error deleting document: ", error);
    }
  };


    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('/img/page-top-bg/5.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>Games</h2>
           
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
  {load?<Loader />:null}
  <section className="page-section spad contact-page" style={{display:display}}>
    <div className="container">
     <div className="row justify-content-end">
      <div className="col-3 mb-5">
      <Link to={'/admin/addgames'}><button className="btn btn-outline-warning">➕ Add Games</button></Link>
      </div>
     </div>
      <div className="row">
        <div className="col-lg-12 p-5" style={{border:"3px solid black",backgroundColor:"black"}}>
          <div className="contact-form-warp table-responsive">
            <h3 className="comment-title text-center text-light">MANAGE GAMES</h3>
           <table class="table text-light table-bordered">
            <thead>
                <tr>
                <th scope="col">Sr No.</th>
                <th scope="col">Game Name</th>
                <th scope="col">Image</th>
                <th scope="col">Category</th>
                <th scope="col">Update</th>
                <th scope="col">Delete</th>
                </tr>
            </thead>
            <tbody>
               {data.map((el, index) => (
                                    <tr key={el.id}>
                                    <th scope="row">{index + 1}</th>
                                            <td>{el.gameName}</td>
                                            <td>
                                                <img src={el.imageUrl} alt={el.gameName} height={300} width={300} />
                                            </td>
                                           <td>{el?.category?.categoryName}</td>
                                       
                                            <td>
                                            <Link to={`/admin/updategame/${el.id}`}>
                                                <button className="btn btn-primary">Update</button>
                                                </Link>
                                            </td>
                                            
                                            <td>
                                                <button
                                                    className="btn btn-danger"
                                                    onClick={() => handleDelete(el.id)}
                                                >
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
            </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page section end */}
</>

        </>
    )
}