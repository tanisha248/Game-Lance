import { createUserWithEmailAndPassword } from "firebase/auth";
import { useEffect, useState } from "react"
import { auth, db } from "../Firebase";
import { collection, deleteDoc, doc, onSnapshot, setDoc, Timestamp } from "firebase/firestore";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import Loader from "../User/Loader";

export default function ManageCategories() {

  const [data, setData] = useState([]);
  const [load, setLoad] = useState(false);
  const [display, setDisplay] = useState("block")

  useEffect(() => {
    setLoad(true)
    setDisplay("none")
    const getCategories = () => {
      const categoryRef = collection(db, "categories");

      const unsubscribe = onSnapshot(categoryRef, (snapshot) => {
        const Categories = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        setData(Categories);
      });

      return () => unsubscribe();
    };

    getCategories();
    setTimeout(() => {
      setLoad(false)
      setDisplay("block")
    }, 500);
  }, []);

  const handleDelete = async (id) => {
    setLoad(true);
    setDisplay("none")
    try {
      const categoryDoc = doc(db, "categories", id);
      await deleteDoc(categoryDoc);
      toast.success("Data Deleted Successfully")
      setTimeout(() => {
        setLoad(false);
        setDisplay("block")
      }, 2000);
      setData(prevData => prevData.filter(category => category.id !== id));
    } catch (error) {
      toast.error("Something went wrong", {
        position: "top-center"
      })
      setTimeout(() => {
        setLoad(false);
        setDisplay("block")
      }, 2000);
      console.error("Error deleting document: ", error);
    }
  };


  return (
    <>
      <>
        {/* Page info section */}
        <section
          className="page-info-section set-bg"
          style={{ backgroundImage: "url('/img/page-top-bg/5.jpg')" }}
        >
          <div className="pi-content">
            <div className="container">
              <div className="row">
                <div className="col-xl-5 col-lg-6 text-white">
                  <h2>Categories</h2>

                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Page info section */}
        {/* Page section */}
        {load ? <Loader /> : null}
        <section className="page-section spad contact-page" style={{ display: display }}>
          <div className="container">
            <div className="row justify-content-end">
              <div className="col-3 mb-5">
                <Link to={'/admin/addcategories'}><button className="btn btn-outline-warning">➕ Add Categories</button></Link>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-12 p-5" style={{ border: "3px solid black", backgroundColor: "black" }}>
                <div className="contact-form-warp">
                  <h3 className="comment-title text-center text-light">MANAGE CATEGORIES</h3>
                  <table class="table text-light table-bordered">
                    <thead>
                      <tr>
                        <th scope="col">Sr No.</th>
                        <th scope="col">Category Name</th>
                        <th scope="col">Image</th>
                        <th scope="col">Update</th>
                        <th scope="col">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.map((el, index) => (
                        <tr key={el.id}>
                          <th scope="row">{index + 1}</th>
                          <td>{el.categoryName}</td>
                          <td>
                            <img src={el.imageUrl} alt={el.categoryName} style={{ width: "100px", height: "auto" }} />
                          </td>

                          <td>
                            <Link to={`/admin/updatecategory/${el.id}`}>
                              <button className="btn btn-primary">Update</button>
                            </Link>
                          </td>
                          <td>
                            <button
                              className="btn btn-danger"
                              onClick={() => handleDelete(el.id)}
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Page section end */}
      </>

    </>
  )
}