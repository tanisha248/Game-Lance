import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import Header from './Layout/User/Header'
import Home from './User/Home'
import Footer from './Layout/User/Footer'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Master from './Layout/User/Master'
import Gallery from './User/Gallery'
import GameReviews from './User/GameReviews'
import Contact from './User/Contact'
import UserRegister from './Authentication/UserRegister'
import UserLogin from './Authentication/UserLogin'
import AdminLogin from './Authentication/AdminLogin'
import AdminMaster from './Layout/Admin/AdminMaster'
import Dashboard from './Admin/Dashboard'
import { ToastContainer } from 'react-toastify'
import AddGames from './Admin/AddGames'
import AddCategory from './Admin/AddCategories'
import ManageCategories from './Admin/ManageCategories'
import ManageGames from './Admin/ManageGames'
import PendingOrders from './Admin/PendingOrders'
import UpdateCategory from './Admin/UpdateCategory'
import Categories from './User/Categories'
import CategoryGames from './User/CategoryGames'
import UpdateGames from './Admin/UpdateGames'
import MakeOrder from './User/MakeOrder'
import MyOrders from './User/MyOrders'
import AcceptedOrders from './Admin/AcceptedOrders'
import RejectedOrders from './Admin/RejectedOrders'
import CanceledOrders from './Admin/CanceledOrders'
import CompletedOrders from './Admin/CompletedOrders'
import ManageEnquiries from './Admin/ManageEnquiries'

function App() {
 
  return (
    <>
     <BrowserRouter>
     <Routes>
      <Route path='/' element={<Master/>}>
      <Route path='/' element={<Home/>}/>
      <Route path='/gallery' element={<Gallery/>}/>
      <Route path='/categories' element={<Categories/>}/>
      <Route path='/games' element={<GameReviews/>}/>
      <Route path='/category-games/:id' element={<CategoryGames/>}/>
      <Route path='/contact' element={<Contact/>}/>
      <Route path='/userregister' element={<UserRegister/>}/>
      <Route path='/userlogin' element={<UserLogin/>}/>
      <Route path='/adminlogin' element={<AdminLogin/>}/>
      <Route path='/makeorder' element={<MakeOrder/>}/>
      <Route path='/myorders' element={<MyOrders/>}/>
      </Route>
      <Route path='/admin' element={<AdminMaster/>}>
        <Route path='/admin' element={<Dashboard/>} />
        <Route path='/admin/addcategories' element={<AddCategory/>}/>
        <Route path='/admin/managecategories' element={<ManageCategories/>}/>
        <Route path='/admin/updatecategory/:id' element={<UpdateCategory/>}/>
        <Route path='/admin/addgames' element={<AddGames/>}/>
        <Route path='/admin/managegames' element={<ManageGames/>}/>
        <Route path='/admin/updategame/:id' element={<UpdateGames/>}/>
        <Route path='/admin/pendingorders' element={<PendingOrders/>}/>
        <Route path='/admin/acceptedorders' element={<AcceptedOrders/>}/>
        <Route path='/admin/rejectedorders' element={<RejectedOrders/>}/>
        <Route path='/admin/canceledorders' element={<CanceledOrders/>}/>
        <Route path='/admin/completedorders' element={<CompletedOrders/>}/>
        <Route path='/admin/manageenquiries' element={<ManageEnquiries/>}/>
      </Route>
     </Routes>
     </BrowserRouter>
     <ToastContainer/>
    </>
  )
}

export default App
