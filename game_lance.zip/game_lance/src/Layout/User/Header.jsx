import { getAuth, onAuthStateChanged, signOut } from "firebase/auth";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

export default function Header(){
   const [user, setUser] = useState(null);
  const auth = getAuth();
  const nav = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, [auth]);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      toast.success("LOGOUT SUCCESSFULLY")
     setTimeout(() => {
       nav('/'); 
     }, 500);// redirect to the home page after logout
      setUser(null); // clear the user state after logout
    } catch (error) {
      console.log("Error signing out: ", error);
    }
  };
    return(
        <>
        <>
  {/* Header section */}
  <header className="header-section">
    <div className="container">
      {/* logo */}
      <Link className="site-logo" href="index.html">
        <Link to="index.html" className="site-logo" style={{ display: "flex", alignItems: "center", textDecoration: "none" }}>
  <img src="img/joystick.png" height={30} alt="Logo" style={{ marginRight: "10px",marginBottom:"10px" }} />
  <h4 className="text-light" >GAMELANCE</h4>
</Link>

      </Link>
      <div className="user-panel">
        {user? (
          <>
          <Link to={'/makeorder'}>Order</Link>/ <Link onClick={handleLogout}>Logout</Link>
          </>
        ):(
          <>
           <Link to={'/userlogin'}>Login</Link> / <Link to={'/userregister'}>Register</Link>
        / <Link to={'/adminlogin'}>Admin</Link>
          </>
        )}
       
      </div>
      {/* responsive */}
      <div className="nav-switch">
        <i className="fa fa-bars" />
      </div>
      {/* site menu */}
      <nav className="main-menu">
        <ul>
          <li>
            <Link to={'/'}>Home</Link>
          </li>
          <li>
            <Link to={'/categories'}>Categories</Link>
          </li>
          <li>
            <Link to={'/games'}>Games</Link>
          </li>
          <li>
            <Link to={'/gallery'}>Gallery</Link>
          </li>
          <li>
            <Link to={'/contact'}>Contact</Link>
          </li>
          
        </ul>
      </nav>
    </div>
  </header>
  {/* Header section end */}
</>

        </>
    )
}