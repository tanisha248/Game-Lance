import { getAuth, signOut } from "firebase/auth";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

export default function AdminHeader(){
  const auth = getAuth();
  const nav = useNavigate();

  const handleLogout = async () => {
    try {
      await signOut(auth);
      toast.success("LOGOUT SUCCESSFULLY")
      setTimeout(() => {
        nav('/');
      }, 500); // redirect to the home page after logout
    } catch (error) {
      console.log("Error signing out: ", error);
    }
  };
    return(
        <>
        <>
  {/* Header section */}
  <header className="header-section">
    <div className="container">
      {/* logo */}
     
        <Link to="index.html" className="site-logo" style={{ display: "flex", alignItems: "center", textDecoration: "none" }}>
  <img src="img/joystick.png" height={30} alt="Logo" style={{ marginRight: "10px",marginBottom:"10px" }} />
  <h4 className="text-light" >GAMELANCE</h4>
</Link>
      <div className="user-panel">
        <Link onClick={handleLogout}>Logout</Link>
      </div>
      {/* responsive */}
      <div className="nav-switch">
        <i className="fa fa-bars" />
      </div>
      {/* site menu */}
      <nav className="main-menu">
        <ul>
          <li>
            <Link to={'/admin'}>Dashboard</Link>
          </li>
          <li>
            <Link to={'/admin/addcategories'}>Categories</Link>
          </li>
          <li>
            <Link to={'/admin/addgames'}>Games</Link>
          </li>
          <li>
            <Link to={'/admin/pendingorders'}>Orders</Link>
          </li>
          <li>
            <Link to={'/admin/manageenquiries'}>Enquiries</Link>
          </li>
        </ul>
      </nav>
    </div>
  </header>
  {/* Header section end */}
</>

        </>
    )
}