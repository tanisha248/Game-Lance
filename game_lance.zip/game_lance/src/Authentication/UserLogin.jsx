import { signInWithEmailAndPassword, signInWithPopup, signOut } from "firebase/auth";
import { useEffect, useState } from "react"
import { auth, db, googleProvider } from "../Firebase";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import GoogleButton from "react-google-button";
import Loader from "../User/Loader";

export default function UserLogin(){
  const[email,setEmail]=useState("");
  const[password,setPassword]=useState("");
  const nav = useNavigate();
   const[load,setLoad]=useState(false);
    const[display,setDisplay] = useState("block")
  
    
  
   useEffect(() => {
        setLoad(true)
        setDisplay("none")
    
        setTimeout(() => {
          setLoad(false)
          setDisplay("block")
        }, 1000);
      }, [])


  const handleLogin= async(e)=>{
    e.preventDefault();
    setLoad(true)
    setDisplay("none")
    try{
      const userCredentials = await signInWithEmailAndPassword(auth,email,password);
      const user = userCredentials.user;

      const userDocRef = doc(db,"users",user.uid);
      const userDoc = await getDoc(userDocRef);

      if(userDoc.exists()){
        const userData = userDoc.data();

        if(userData.role==="user" && userData.status==="active"){
          toast.success("Login Successfully")
          setLoad(false)
          setDisplay("block")
            nav('/')
      
        }
        else{
          await signOut();
          toast.error("Access Denied: You are not supposed to access this pannel")
           setLoad(false)
          setDisplay("block")
        }
      }
      else{
        toast.error("User data not found");
         setLoad(false)
          setDisplay("block")
      }
    }
    catch(error){
      toast.error("Invalid Credentials");
          console.log(error);
           setLoad(false)
          setDisplay("block")
    }
  }

  const handleGoogleLogin = async () => {
    setLoad(true)
    setDisplay("none")
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;

    // Extract email and first part as name
    const email = user.email;
    const name = email.split('@')[0];

    // Check if user already exists
    const userDocRef = doc(db, "users", user.uid);
    const userDoc = await getDoc(userDocRef);

    if (!userDoc.exists()) {
      // Add new user to Firestore
      await setDoc(userDocRef, {
        email: email,
        name: name,
        role: "user",       // optional, can add default role
        status: "active"    // optional, can add default status
      });
    }

    toast.success("Login successful", {
      position: "top-center"
    });
     setLoad(false)
    setDisplay("block")

    setTimeout(() => {
      nav("/");
    }, 1000);
  } catch (error) {
    toast.error("Try Again!!");
    console.log(error);
     setLoad(false)
          setDisplay("block")
  }
};

    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('/img/page-top-bg/5.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>User Login</h2>
           
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
  {load?<Loader />:null}
  <section className="page-section spad contact-page" style={{display:display}}>
    <div className="container">
     
      <div className="row">
        <div className="col-lg-12 p-5" style={{border:"3px solid black",backgroundColor:"black"}}>
          <div className="contact-form-warp">
            <h3 className="comment-title text-center text-light">LOGIN HERE</h3>
            <form className="comment-form" onSubmit={handleLogin}>
              <div className="row">
                
                <div className="col-md-6">
                     <label className="text-light">Enter Email:</label>
                  <input type="email"
                  value={email} onChange={(e)=>{setEmail(e.target.value)}}
                  className="form-control" placeholder="Email" />
                </div>
                <div className="col-md-6">
                     <label className="text-light">Enter Password:</label>
                  <input type="password"
                  value={password} onChange={(e)=>{setPassword(e.target.value)}}
                  className="form-control" placeholder="Password" />
                </div>
                
                <div className="col-lg-12">
                  <button className="site-btn btn-lg w-50 offset-md-3">Login</button>
                </div>
              </div>
            </form>
            <div className="col-md-12">
                    <hr></hr>
                    <p className='text-center mb-3'>OR</p>
                    <div className='offset-md-5 mt-3'>
                      <GoogleButton onClick={handleGoogleLogin} />
                    </div>
                    
                  </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page section end */}
</>

        </>
    )
}