import { createUserWithEmailAndPassword } from "firebase/auth";
import { useState } from "react"
import { auth, db } from "../Firebase";
import { doc, setDoc, Timestamp } from "firebase/firestore";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import Loader from "../User/Loader";

export default function UserRegister(){
  const[name,setName]=useState("");
  const[email,setEmail]=useState("");
  const[password,setPassword]=useState("");
  const[contact,setContact]=useState("");
  const[address,setAddress]=useState("");
  const nav = useNavigate();
  const[load,setLoad]=useState(false);
    const[display,setDisplay] = useState("block")
  
    const handleRegister= async(e)=>{
    e.preventDefault();
      setLoad(true)
      setDisplay("none")
    try{
      const userCredentials = await createUserWithEmailAndPassword(auth,email,password)
      const user = userCredentials.user

      const newUser={
        name,
        email,
        password,
        contact,
        address,
        uid:user.uid,
        status:"active",
        role:"user",
        created_at:Timestamp.now()
      }

      const userRef= doc(db,"users",user.uid)
      await setDoc(userRef,newUser)

      toast.success("User Registered Successfully")
     setLoad(false)
     setDisplay("block")
        nav('/')
      
    }
   catch (error) {
                if (error.code === "auth/email-already-in-use") {
                    toast.error("Email already exists");
                     setLoad(false)
     setDisplay("block")
                } else {
                    toast.error("Something went wrong!!!");
                    console.log("Error details:", error);
                      setLoad(false)
     setDisplay("block")
                }
            }
  }

    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('img/page-top-bg/5.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>User Register</h2>
           
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
  {load?<Loader />:null}
  <section className="page-section spad contact-page" style={{display:display}}>
    <div className="container">
     
      <div className="row">
        <div className="col-lg-12 p-5" style={{border:"3px solid black",backgroundColor:"black"}}>
          <div className="contact-form-warp">
            <h3 className="comment-title text-center text-light">REGISTER HERE</h3>
            <form className="comment-form" onSubmit={handleRegister}>
              <div className="row">
                <div className="col-md-6">
                    <label className="text-light">Enter Name:</label>
                  <input type="text"
                  value={name}
                  onChange={(e)=>setName(e.target.value)}
                  className="form-control" placeholder="Name" />
                </div>
                <div className="col-md-6">
                     <label className="text-light">Enter Email:</label>
                  <input type="email" 
                  value={email} onChange={(e)=>setEmail(e.target.value)}
                  className="form-control" placeholder="Email" />
                </div>
                <div className="col-md-6">
                     <label className="text-light">Enter Password:</label>
                  <input type="password"
                  value={password} onChange={(e)=>{setPassword(e.target.value)}}
                  className="form-control" placeholder="Password" />
                </div>
                <div className="col-md-6">
                     <label className="text-light">Enter Contact:</label>
                  <input type="text"
                  value={contact} onChange={(e)=>{setContact(e.target.value)}}
                  className="form-control" maxLength={10} minLength={10} placeholder="Contact" />
                </div>
                <div className="col-lg-12">
                <label className="text-light">Enter Address:</label>
                  <textarea placeholder="Message" 
                  value={address} onChange={(e)=>{setAddress(e.target.value)}}
                  className="form-control" defaultValue={""} />
                  <button className="site-btn btn-lg w-50 offset-md-3">Register</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page section end */}
</>

        </>
    )
}