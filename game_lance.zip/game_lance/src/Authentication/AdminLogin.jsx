import { signInWithEmailAndPassword, signOut } from "firebase/auth";
import { useEffect, useState } from "react"
import { auth, db } from "../Firebase";
import { doc, getDoc } from "firebase/firestore";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import Loader from "../User/Loader";

export default function AdminLogin(){
  const[email,setEmail]=useState("");
  const[password,setPassword]=useState("");
  const[load,setLoad]=useState(false);
  const[display,setDisplay] = useState("block")

  const nav = useNavigate();

   useEffect(() => {
      setLoad(true)
      setDisplay("none")
  
      setTimeout(() => {
        setLoad(false)
        setDisplay("block")
      }, 1000);
    }, [])
  

  const handleLogin= async(e)=>{
    e.preventDefault();
    setLoad(true)
    setDisplay("none")
    try{
      const userCredentials = await signInWithEmailAndPassword(auth,email,password);
      const user = userCredentials.user;

      const userDocRef = doc(db,"users",user.uid);
      const userDoc = await getDoc(userDocRef)

      if(userDoc.exists()){
        const userData = userDoc.data();

        if(userData.role==="admin" && userData.status==="active"){
          toast.success("Login Successfully")
         setLoad(false)
         setDisplay("block")
            nav('/admin')
         
        }
        else{
          await signOut(auth);
          toast.error("Access denied you are not allowed to access this portal")
            setLoad(false)
         setDisplay("block")
        }
      }
      else{
        toast.error("User Not Found");
          setLoad(false)
         setDisplay("block")
      }
    }
    catch(error){
      toast.error("Invalid Credentials")
      console.log(error)
        setLoad(false)
         setDisplay("block")
    }
  }

    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('img/page-top-bg/5.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>Admin Login</h2>
           
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
 
  <section className="page-section spad contact-page" >
     {load?<Loader />:null}
    <div className="container" style={{display:display}}>
     
      <div className="row">
        <div className="col-lg-12 p-5" style={{border:"3px solid black",backgroundColor:"black"}}>
          <div className="contact-form-warp">
            <h3 className="comment-title text-center text-light">LOGIN HERE</h3>
            <form className="comment-form" onSubmit={handleLogin}>
              <div className="row">
                
                <div className="col-md-6">
                     <label className="text-light">Enter Email:</label>
                  <input type="email"
                  value={email} onChange={(e)=>{setEmail(e.target.value)}}
                  className="form-control" placeholder="Email" />
                </div>
                <div className="col-md-6">
                     <label className="text-light">Enter Password:</label>
                  <input type="password"
                  value={password} onChange={(e)=>{setPassword(e.target.value)}}
                  className="form-control" placeholder="password" />
                </div>
                
                <div className="col-lg-12">
                  <button className="site-btn btn-lg w-50 offset-md-3">Login</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page section end */}
</>

        </>
    )
}