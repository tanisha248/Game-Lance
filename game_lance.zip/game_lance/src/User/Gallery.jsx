import { useEffect, useState } from "react"
import Loader from "./Loader"

export default function Gallery() {
  const [load, setLoad] = useState(false)
  const [display, setDisplay] = useState("block")

  useEffect(() => {
    setLoad(true)
    setDisplay("none")

    setTimeout(() => {
      setLoad(false)
      setDisplay("block")
    }, 1000);
  }, [])


  return (
    <>
      <>
        {/* Page info section */}
        <section
          className="page-info-section set-bg"
          style={{ backgroundImage: "url('img/page-top-bg/1.jpg')" }}
        >
          <div className="pi-content">
            <div className="container">
              <div className="row">
                <div className="col-xl-5 col-lg-6 text-white">
                  <h2>Video Gallery</h2>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec
                    malesuada lorem maximus mauris scelerisque, at rutrum nulla
                    dictum.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Page info section */}
        {/* Page section */}
        {load ? <Loader /> : null}
        <section className="page-section recent-game-page spad " style={{ display: display }}>
          <div className="container">
            <div className="row">
              <div className="col-lg-8">
                <div className="row">
                  <div className="col-md-6">
                    <div className="recent-game-item">
                      <div
                        className="rgi-thumb set-bg"
                        style={{ backgroundImage: "url('img/recent-game/1.jpg')" }}
                      >
                        <div className="cata new">racing</div>
                      </div>
                      <div className="rgi-content">
                        
                        
                        

                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="recent-game-item">
                      <div
                        className="rgi-thumb set-bg"
                        style={{ backgroundImage: "url('img/recent-game/2.jpg')" }}
                      >
                        <div className="cata racing">racing</div>
                      </div>
                      <div className="rgi-content">
                       
                        
                        

                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="recent-game-item">
                      <div
                        className="rgi-thumb set-bg"
                        style={{ backgroundImage: "url('img/recent-game/3.jpg')" }}
                      >
                        <div className="cata adventure">Adventure</div>
                      </div>
                      <div className="rgi-content">
                       
                        
                        

                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="recent-game-item">
                      <div
                        className="rgi-thumb set-bg"
                        style={{ backgroundImage: "url('img/recent-game/4.jpg')" }}
                      >
                        <div className="cata new">racing</div>
                      </div>
                      <div className="rgi-content">
                        
                        
                        

                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="recent-game-item">
                      <div
                        className="rgi-thumb set-bg"
                        style={{ backgroundImage: "url('img/recent-game/5.jpg')" }}
                      >
                        <div className="cata racing">racing</div>
                      </div>
                      <div className="rgi-content">
                       
                        
                        

                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="recent-game-item">
                      <div
                        className="rgi-thumb set-bg"
                        style={{ backgroundImage: "url('img/recent-game/6.jpg')" }}
                      >
                        <div className="cata adventure">Adventure</div>
                      </div>
                      <div className="rgi-content">
                       
                        
                        

                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="recent-game-item">
                      <div
                        className="rgi-thumb set-bg"
                        style={{ backgroundImage: "url('img/recent-game/7.jpg')" }}
                      >
                        <div className="cata new">racing</div>
                      </div>
                      <div className="rgi-content">
                        
                        
                        

                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="recent-game-item">
                      <div
                        className="rgi-thumb set-bg"
                        style={{ backgroundImage: "url('img/recent-game/8.jpg')" }}
                      >
                        <div className="cata racing">racing</div>
                      </div>
                      <div className="rgi-content">
                       
                        
                        

                      </div>
                    </div>
                  </div>
                </div>
                <div className="site-pagination">
                  <span className="active">01.</span>
                  <a href="#">02.</a>
                  <a href="#">03.</a>
                </div>
              </div>
              {/* sidebar */}
              <div className="col-lg-4 col-md-7 sidebar pt-5 pt-lg-0">
                {/* widget */}
                <div className="widget-item">
                  <form className="search-widget">
                    <input type="text" placeholder="Search" />
                    <button>
                      <i className="fa fa-search" />
                    </button>
                  </form>
                </div>
                {/* widget */}
                <div className="widget-item">
                  <h4 className="widget-title">Latest Posts</h4>
                  <div className="latest-blog">
                    <div className="lb-item">
                      <div
                        className="lb-thumb set-bg"
                        style={{ backgroundImage: "url('img/latest-blog/1.jpg')" }}
                      />
                      <div className="lb-content">
                        <div className="lb-date">June 21, 2018</div>
                        <p>Ipsum dolor sit amet, consectetur adipisc ing consecips</p>
                        <a href="#" className="lb-author">
                          By Admin
                        </a>
                      </div>
                    </div>
                    <div className="lb-item">
                      <div
                        className="lb-thumb set-bg"
                        style={{ backgroundImage: "img/latest-blog/2.jpg" }}
                      />
                      <div className="lb-content">
                        <div className="lb-date">June 21, 2018</div>
                        <p>Ipsum dolor sit amet, consectetur adipisc ing consecips</p>
                        <a href="#" className="lb-author">
                          By Admin
                        </a>
                      </div>
                    </div>
                    <div className="lb-item">
                      <div
                        className="lb-thumb set-bg"
                        style={{ backgroundImage: "url('img/latest-blog/3.jpg')" }}
                      />
                      <div className="lb-content">
                        <div className="lb-date">June 21, 2018</div>
                        <p>Ipsum dolor sit amet, consectetur adipisc ing consecips</p>
                        <a href="#" className="lb-author">
                          By Admin
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                {/* widget */}
                <div className="widget-item">
                  <h4 className="widget-title">Top Comments</h4>
                  <div className="top-comment">
                    <div className="tc-item">
                      <div
                        className="tc-thumb set-bg"
                        style={{ backgroundImage: "img/authors/1.jpg" }}
                      />
                      <div className="tc-content">
                        <p>
                          <a href="#">James Smith</a> <span>on</span> Lorem consec
                          ipsum dolor sit amet, co
                        </p>
                        <div className="tc-date">June 21, 2018</div>
                      </div>
                    </div>
                    <div className="tc-item">
                      <div
                        className="tc-thumb set-bg"
                        style={{ backgroundImage: "img/authors/2.jpg" }}
                      />
                      <div className="tc-content">
                        <p>
                          <a href="#">Michael James</a> <span>on</span>Cras sit amet
                          sapien aliquam
                        </p>
                        <div className="tc-date">June 21, 2018</div>
                      </div>
                    </div>
                    <div className="tc-item">
                      <div
                        className="tc-thumb set-bg"
                        data-setbg="img/authors/3.jpg"
                      />
                      <div className="tc-content">
                        <p>
                          <a href="#">Justin More</a> <span>on</span> Lorem ipsum
                          dolor consecsit amet, co
                        </p>
                        <div className="tc-date">June 21, 2018</div>
                      </div>
                    </div>
                  </div>
                </div>
                {/* widget */}
                <div className="widget-item">
                  <div
                    className="feature-item set-bg"
                    style={{ backgroundImage: "url('img/features/1.jpg')" }}
                  >
                    <span className="cata new">new</span>
                    <div className="fi-content text-white">
                      <h5>
                        <a href="#">Suspendisse ut justo tem por, rutrum</a>
                      </h5>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                      <a href="#" className="fi-comment">
                        3 Comments
                      </a>
                    </div>
                  </div>
                </div>
                {/* widget */}
                <div className="widget-item">
                  <div className="review-item">
                    <div
                      className="review-cover set-bg"
                      style={{ backgroundImage: "url('img/review/1.jpg')" }}
                    >
                      <div className="score yellow">9.3</div>
                    </div>
                    <div className="review-text">
                      <h5>Assasin’’s Creed</h5>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum
                        dolor sit ame.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Page section end */}
        {/* Footer top section */}
        <section className="footer-top-section" style={{ display: display }}>
          <div className="container">
            <div className="footer-top-bg">
              <img src="img/footer-top-bg.png" alt="" />
            </div>
            <div className="row">
              <div className="col-lg-4">
                <div className="footer-logo text-white">
                  <img src="img/footer-logo.png" alt="" />
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum dolor
                    sit ame.
                  </p>
                </div>
              </div>
              <div className="col-lg-4 col-md-6">
                <div className="footer-widget mb-5 mb-md-0">
                  <h4 className="fw-title">Latest Posts</h4>
                  <div className="latest-blog">
                    <div className="lb-item">
                      <div
                        className="lb-thumb set-bg"
                        style={{ backgroundImage: "url('img/latest-blog/1.jpg')" }}
                      />
                      <div className="lb-content">
                        <div className="lb-date">June 21, 2018</div>
                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum{" "}
                        </p>
                        <a href="#" className="lb-author">
                          By Admin
                        </a>
                      </div>
                    </div>
                    <div className="lb-item">
                      <div
                        className="lb-thumb set-bg"
                        style={{ backgroundImage: "url('img/latest-blog/2.jpg')" }}
                      />
                      <div className="lb-content">
                        <div className="lb-date">June 21, 2018</div>
                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum{" "}
                        </p>
                        <a href="#" className="lb-author">
                          By Admin
                        </a>
                      </div>
                    </div>
                    <div className="lb-item">
                      <div
                        className="lb-thumb set-bg"
                        style={{ backgroundImage: "url('img/latest-blog/3.jpg')" }}
                      />
                      <div className="lb-content">
                        <div className="lb-date">June 21, 2018</div>
                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum{" "}
                        </p>
                        <a href="#" className="lb-author">
                          By Admin
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-4 col-md-6">
                <div className="footer-widget">
                  <h4 className="fw-title">Top Comments</h4>
                  <div className="top-comment">
                    <div className="tc-item">
                      <div
                        className="tc-thumb set-bg"
                        style={{ backgroundImage: "url('img/authors/1.jpg')" }}
                      />
                      <div className="tc-content">
                        <p>
                          <a href="#">James Smith</a> <span>on</span> Lorem ipsum
                          dolor sit amet, co
                        </p>
                        <div className="tc-date">June 21, 2018</div>
                      </div>
                    </div>
                    <div className="tc-item">
                      <div
                        className="tc-thumb set-bg"
                        style={{ backgroundImage: "url('img/authors/2.jpg')" }}
                      />
                      <div className="tc-content">
                        <p>
                          <a href="#">James Smith</a> <span>on</span> Lorem ipsum
                          dolor sit amet, co
                        </p>
                        <div className="tc-date">June 21, 2018</div>
                      </div>
                    </div>
                    <div className="tc-item">
                      <div
                        className="tc-thumb set-bg"
                        style={{ backgroundImage: "url('img/authors/3.jpg')" }}
                      />
                      <div className="tc-content">
                        <p>
                          <a href="#">James Smith</a> <span>on</span> Lorem ipsum
                          dolor sit amet, co
                        </p>
                        <div className="tc-date">June 21, 2018</div>
                      </div>
                    </div>
                    <div className="tc-item">
                      <div
                        className="tc-thumb set-bg"
                        style={{ backgroundImage: "url('img/authors/4.jpg')" }}
                      />
                      <div className="tc-content">
                        <p>
                          <a href="#">James Smith</a> <span>on</span> Lorem ipsum
                          dolor sit amet, co
                        </p>
                        <div className="tc-date">June 21, 2018</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Footer top section end */}
      </>

    </>
  )
}