import { getAuth } from "firebase/auth";
import { addDoc, collection, Timestamp } from "firebase/firestore";
import { useEffect, useState } from "react"
import { toast } from "react-toastify";
import { db } from "../Firebase";
import { useNavigate } from "react-router-dom";
import Loader from "./Loader";

export default function Contact(){
  const[name,setName]=useState("");
  const[email,setEmail]=useState("");
  const[subject,setSubject]=useState("");
  const[message,setMessage]=useState("");
  const nav = useNavigate();
   const[load,setLoad] = useState(false)
  const[display,setDisplay] = useState("block")

   useEffect(() =>{
setLoad(true)
setDisplay("none")

setTimeout(() => {
  setLoad(false)
  setDisplay("block")
}, 1000);
  },[])
  const addQuery= async(e)=>{
    e.preventDefault();
    setLoad(true)
    setDisplay("none")

    try{
           const queryRef = collection(db,"queries")
           let newQuery={
            name,
            email,
            subject,
            message,
            status:"active",
            created_at:Timestamp.now()
           }

           await addDoc(queryRef,newQuery)
           toast.success("Message Sent Successfully")
           setLoad(false)
           setDisplay("block")

    }
    catch(error){
      toast.error("Something Went wrong")
      console.log(error)
       setLoad(false)
      setDisplay("block")

    }
  }

    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('img/page-top-bg/5.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>Contact us</h2>
            
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
  {load?<Loader />:null}
  <section className="page-section spad contact-page" style={{display:display}}>
    <div className="container">
      <div className="map" >
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d54414.51315077385!2d75.87909296962272!3d31.526712161509458!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391ae2d1a5455fb5%3A0x4d51e31e87ee92da!2sHoshiarpur%2C%20Punjab!5e0!3m2!1sen!2sin!4v1750483765054!5m2!1sen!2sin" width="100%" height="100%" 
         allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div>
      <div className="row">
        <div className="col-lg-4 mb-5 mb-lg-0">
          <h4 className="comment-title">Contact us</h4>
         
          <div className="row">
            <div className="col-md-9">
              <ul className="contact-info-list">
                <li>
                  <div className="cf-left">Address</div>
                  <div className="cf-right">
                    1481 Creekside Lane Avila Beach, CA 931
                  </div>
                </li>
                <li>
                  <div className="cf-left">Phone</div>
                  <div className="cf-right">+53 345 7953 32453</div>
                </li>
                <li>
                  <div className="cf-left">E-mail</div>
                  <div className="cf-right">yourmail@gmail.com</div>
                </li>
              </ul>
            </div>
          </div>
          <div className="social-links">
            <a href="#">
              <i className="fa fa-pinterest" />
            </a>
            <a href="#">
              <i className="fa fa-facebook" />
            </a>
            <a href="#">
              <i className="fa fa-twitter" />
            </a>
            <a href="#">
              <i className="fa fa-dribbble" />
            </a>
            <a href="#">
              <i className="fa fa-behance" />
            </a>
            <a href="#">
              <i className="fa fa-linkedin" />
            </a>
          </div>
        </div>
        <div className="col-lg-8">
          <div className="contact-form-warp">
            <h4 className="comment-title">Leave a Reply</h4>
            <form className="comment-form" onSubmit={addQuery}>
              <div className="row">
                <div className="col-md-6">
                  <label>Enter Name:</label>
                  <input type="text" className="form-control"
                  value={name} onChange={(e)=>{setName(e.target.value)}}
                  placeholder="Name" />
                </div>
                <div className="col-md-6">
                  <label>Enter Email:</label>
                  <input type="email" className="form-control" 
                  value={email} onChange={(e)=>{setEmail(e.target.value)}}
                  placeholder="Email" />
                </div>
                <div className="col-lg-12">
                  <label>Enter Subject</label>
                  <input type="text" className="form-control"
                  value={subject} onChange={(e)=>{setSubject(e.target.value)}}
                  placeholder="Subject" />
                  <label>Enter Message</label>
                  <textarea placeholder="Message" className="form-control" value={message} onChange={(e)=>setMessage(e.target.value)} defaultValue={""} />
                  <button className="site-btn btn-sm">Send</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page section end */}
</>

        </>
    )
}