 import { ClipLoader, HashLoader, MoonLoader } from "react-spinners";

export default function Loader()
{
    return(
        <>
        <div className="container">
            <div className="row " style={{height:"80vh",display:"flex",alignItems:"center",justifyContent:"center"}}>
                <div className="col-3 mx-auto" style={{display:"flex",alignItems:"center",justifyContent:"center"}} >
                <HashLoader  size={"70"} loading={true} />
                </div>
            </div>
        </div>
        </>
    )
}