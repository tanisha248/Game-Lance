import { createUserWithEmailAndPassword, getAuth } from "firebase/auth";
import { useEffect, useState } from "react"
import { auth, db } from "../Firebase";
import { addDoc, collection, doc, getDocs, onSnapshot, query, setDoc, Timestamp, where } from "firebase/firestore";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import Loader from "./Loader";

export default function MakeOrder(){
  const[gameName,setGameName]=useState("");
  const[budget,setBudget]=useState("");
  const[description,setDescription]=useState("");
  const[deadline,setDeadline]=useState("");
  const[categoryId,setCategoryId]=useState("")
  const[platform,setPlatform]=useState("")
  const nav = useNavigate();
   const[load,setLoad]=useState(false);
   const[display,setDisplay] = useState("block")
    const [data, setData] = useState([]);



useEffect(() => {
          setLoad(true)
          setDisplay("none")
           const getCategories = () => {
               const categoryRef = collection(db, "categories");
   
               const unsubscribe = onSnapshot(categoryRef, (snapshot) => {
                   const Categories = snapshot.docs.map(doc => ({
                       id: doc.id,
                       ...doc.data()
                   }));
                   setData(Categories);
               });
   
               return () => unsubscribe();
           };
   
           getCategories();
           setTimeout(() => {
            setLoad(false)
            setDisplay("block")
           }, 1000);
       }, []);

   const addOrder = async (e) => {
       e.preventDefault();
        setLoad(true);
        setDisplay("none")

       try {
           const auth = getAuth();
           const user = auth.currentUser;

           if (!user) {
               toast.error("User is not authenticated", {
                   position: "top-center"
               });
               setLoad(false);
               setDisplay("block")
               return;
           }

           const gameRef = collection(db, "orders");
           const newgame = {
               gameName,
               budget,
               deadline,
               description,
               categoryId,
               platform,
               userId: user.uid,
               status: "Pending",
               created_at: Timestamp.now(),
           };

           await addDoc(gameRef, newgame);
           toast.success("Order Request Sent Successfully", {
               position: "top-center",
           });
        
           setTimeout(() => {
            setLoad(false)
            setDisplay("block")
               nav("/myorders");
           }, 2000);
       } catch (error) {
           toast.error("Something Went Wrong", {
               position: "top-center"
           });
          setLoad(false);
            setDisplay("block");
           console.log(error);
       }
   };


    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('/img/page-top-bg/5.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>Order</h2>
           
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
  {load?<Loader />:null}
  <section className="page-section spad contact-page" style={{display:display}}>
    <div className="container">
     <div className="row justify-content-end">
      <div className="col-3 mb-5">
      <Link to={'/myorders'}><button className="btn btn-outline-warning">📋 Manage Order</button></Link>
      </div>
     </div>
      <div className="row">
        <div className="col-lg-12 p-5" style={{border:"3px solid black",backgroundColor:"black"}}>
          <div className="contact-form-warp">
            <h3 className="comment-title text-center text-light">ADD ORDER</h3>
            <form className="comment-form" onSubmit={addOrder}>
              <div className="row">
                <div className="col-md-6">
                    <label className="text-light">Enter Game Name:</label>
                  <input type="text"
                  value={gameName}
                  required
                  onChange={(e)=>setGameName(e.target.value)}
                  className="form-control" placeholder="Game Name" />
                </div>
                <div className="col-md-6">
                    <label className="text-light">Select Category:</label>
                  <select type="text"
                   required
                  value={categoryId}
                  onChange={(e)=>setCategoryId(e.target.value)}
                  className="form-control" placeholder="Name" >
                    <option>Select Category</option>
                    {data?.map((el,index)=>(
                      <>
                      <option value={el.id}>{el.categoryName}</option>
                      </>
                    ))}
                  </select>
                </div>

                <div className="col-md-6">
                     <label className="text-light">Enter Budget</label>
                  <input type="text"
                  value={budget}  required onChange={(e)=>{setBudget(e.target.value)}}
                  className="form-control" placeholder="Budget" />
                </div>
                <div className="col-md-6">
                     <label className="text-light">Choose Deadline</label>
                  <input type="date" 
                  value={deadline}  required onChange={(e)=>{setDeadline(e.target.value)}}
                  className="form-control" placeholder="Budget" />
                </div>
                <div className="col-md-12">
                     <label className="text-light">Enter Platforms</label>
                  <textarea  className="form-control"
                  value={platform}  required onChange={(e)=>{setPlatform(e.target.value)}}
                  placeholder="eg.web,android,ios" />
                </div>
                  <div className="col-md-12 mt-3">
                    <label className="text-light">Enter Description:</label>
                  <textarea 
                  value={description}
                  onChange={(e)=>setDescription(e.target.value)}
                  className="form-control"  required placeholder="Description" />
                </div>

                <div className="col-lg-12">
                  <button className="site-btn btn-lg w-50 offset-md-3">Save</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page section end */}
</>

        </>
    )
}