import { createUserWithEmailAndPassword } from "firebase/auth";
import { useEffect, useState } from "react"
import { auth, db } from "../Firebase";
import { collection, doc, getDocs, onSnapshot, setDoc, Timestamp } from "firebase/firestore";
import { toast } from "react-toastify";
import { Link, useNavigate, useParams } from "react-router-dom";
export default function Practice(){
  const [data, setData] = useState([]);
      const[load,setLoad]=useState(true);
  const {id} = useParams();
      // setTimeout(() => {
      //     setLoad(false);
      // }, 1000);
  
      useEffect(()=>{
          getGames();
      },[id])

      const getGames = async () => {
  try {
    const categoryCollection = collection(db, "categories");
    const gameCollection = collection(db, "games");

    const categoriesData = await getDocs(categoryCollection);
    const gamesData = await getDocs(gameCollection);

    const categories = categoriesData.docs.map(doc => ({
      ...doc.data(),
      id: doc.id
    }));

    const games = gamesData.docs
      .map(doc => ({ ...doc.data(), id: doc.id }))
      .filter(game => game.categoryId === id); // ✅ Filter by categoryId from params

    const joinedData = games.map(gameData => {
      const categoryData = categories.find(category => category.id === gameData.categoryId);
      return {
        ...gameData,
        category: categoryData
      };
    });

    setData(joinedData);
    console.log("Filtered games:", joinedData);
  } catch (error) {
    console.error("Error fetching games:", error);
  }
};

  
  
    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('/img/page-top-bg/3.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>Game reviews</h2>
            
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
  <section className="page-section review-page spad">
    <div className="container">
      <div className="row">
       {data.map((el)=>(
        <>
         <div className="col-md-6">
          <div className="review-item">
            <div className="review-cover set-bg" style={{ backgroundImage: `url(${el.imageUrl})` }}>
             
            </div>
            <div className="review-text">
              <h4>{el.gameName}</h4>
              <h5>{el?.category?.categoryName}</h5>
              <div className="rating">
                {
                                                el?.averageRating ==5 ? (
                                                    <>
                                                    ⭐⭐⭐⭐⭐
                                                    </>
                                                ) : el?.averageRating==4 ?(
                                                    <>
                                                    ⭐⭐⭐⭐
                                                    </>
                                                ):el?.averageRating==3 ? (
                                                    <>⭐⭐⭐</>
                                                ):el?.averageRating==2 ?(
                                                    <>
                                                    ⭐⭐
                                                    </>
                                                ):(
                                                    <>⭐</>
                                                )
                                            }
              </div>
              <p>
                {el?.description}
              </p>
            </div>
          </div>
        </div>
        </>
       ))}
        
      </div>
     
    </div>
  </section>
  {/* Page section end */}
  {/* Review section */}
 
  {/* Review section end */}
</>

        </>
    )
}