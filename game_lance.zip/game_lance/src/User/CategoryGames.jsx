import { useEffect, useState } from "react";
import { auth, db } from "../Firebase";
import {
  collection,
  doc,
  getDocs,
  updateDoc,
  arrayUnion,
  arrayRemove,
  addDoc,
  query,
  orderBy,
} from "firebase/firestore";
import { toast } from "react-toastify";
import { useParams } from "react-router-dom";
import Loader from "./Loader";

export default function CategoryGames() {
  const [data, setData] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [activeGameId, setActiveGameId] = useState(null);
  const [viewCommentsOpen, setViewCommentsOpen] = useState(false);
  const [comments, setComments] = useState([]);
  const[load,setLoad] = useState(false)
  const[display,setDisplay] = useState("block")
  const {id} = useParams();

  useEffect(() => {
   
    getGames();
   
  }, []);

 const getGames = async () => {
   setLoad(true)
    setDisplay("none")
  try {
    const categoryCollection = collection(db, "categories");
    const gameCollection = collection(db, "games");

    const [categoriesData, gamesData] = await Promise.all([
      getDocs(categoryCollection),
      getDocs(gameCollection),
    ]);

    const categories = categoriesData.docs.map((doc) => ({
      ...doc.data(),
      id: doc.id,
    }));

    
    const games = gamesData.docs
      .map((doc) => ({ ...doc.data(), id: doc.id }))
      .filter((game) => game.categoryId === id); // id comes from useParams()

    const joinedData = games.map((game) => {
      const category = categories.find((cat) => cat.id === game.categoryId);
      const likedByCurrentUser = game.likes?.includes(auth.currentUser?.uid);
      return {
        ...game,
        category,
        likedByCurrentUser: likedByCurrentUser || false,
        likeCount: game.likes?.length || 0,
      };
    });

    setData(joinedData);
  } catch (error) {
    console.error("Error fetching games:", error);
  }
   setLoad(false)
    setDisplay("block")
};


  const toggleLike = async (gameId, liked) => {
    const userId = auth.currentUser?.uid;
    if (!userId) return toast.error("You must be logged in to like.");

    const gameRef = doc(db, "games", gameId);
    try {
      if (liked) {
        await updateDoc(gameRef, {
          likes: arrayRemove(userId),
        });
      } else {
        await updateDoc(gameRef, {
          likes: arrayUnion(userId),
        });
      }
      getGames(); // Refresh
    } catch (err) {
      console.error("Failed to update like:", err);
    }
  };

  const openModal = (gameId) => {
    setActiveGameId(gameId);
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setCommentText("");
    setActiveGameId(null);
  };

 const handleAddComment = async () => {
  if (!commentText.trim()) {
    return toast.error("Comment cannot be empty.");
  }

  const userId = auth.currentUser?.uid;
  if (!userId) return toast.error("User not logged in");

  try {
    
    const usersSnapshot = await getDocs(collection(db, "users"));
    const currentUserDoc = usersSnapshot.docs.find((doc) => doc.id === userId);

    let userName = "Anonymous";
    if (currentUserDoc && currentUserDoc.exists()) {
      const userData = currentUserDoc.data();
      userName = userData.name || userData.username || "👤";
    }

    await addDoc(collection(db, "games", activeGameId, "comments"), {
      userId,
      userName,
      text: commentText,
      createdAt: new Date(),
    });

    toast.success("Comment added!");
    closeModal();
  } catch (err) {
    console.error("Error adding comment:", err);
    toast.error("Failed to add comment.");
  }
};


  const fetchComments = async (gameId) => {
    try {
      const commentsRef = collection(db, "games", gameId, "comments");
      const commentsSnapshot = await getDocs(
        query(commentsRef, orderBy("createdAt", "desc"))
      );
      const commentsData = commentsSnapshot.docs.map((doc) => doc.data());
      setComments(commentsData);
      setViewCommentsOpen(true);
    } catch (err) {
      console.error("Error fetching comments:", err);
      toast.error("Failed to fetch comments.");
    }
  };

  return (
    <>
      <section
        className="page-info-section set-bg"
        style={{ backgroundImage: "url('/img/slider-1.jpg')" }}
      >
        <div className="pi-content">
          <div className="container">
            <div className="row">
              <div className="col-xl-5 col-lg-6 text-white">
                <h2>Games</h2>
              </div>
            </div>
          </div>
        </div>
      </section>
    {load?<Loader />:null}
      <section className="page-section review-page spad" style={{display:display}}>
        <div className="container">
          <div className="row">
            {data.map((el) => (
              <div className="col-md-6" key={el.id}>
                <div className="review-item">
                  <div
                    className="review-cover set-bg"
                    style={{ backgroundImage: `url(${el.imageUrl})` }}
                  ></div>
                  <div className="review-text">
                    <h4>{el.gameName}</h4>
                    <h5>{el?.category?.categoryName}</h5>
                    
                    <p>{el?.description}</p>

                    <div className="d-flex align-items-center gap-3 mt-2">
                      <button
                        className="btn"
                        onClick={() => toggleLike(el.id, el.likedByCurrentUser)}
                        style={{
                          fontSize: "24px",
                          color: el.likedByCurrentUser ? "red" : "gray",
                        }}
                      >
                        {el.likedByCurrentUser ? "❤️" : "🤍"}
                      </button>
                      <span style={{ color: "black" }}>
                        {el.likeCount} Likes
                      </span>

                      <button
                        className="btn btn-outline-info ms-3" style={{marginLeft:"10px"}}
                        onClick={() => openModal(el.id)}
                      >
                        💬 Add Comment
                      </button>

                      <button
                        className="btn btn-outline-success text-dark" style={{marginLeft:"5px"}}
                        onClick={() => fetchComments(el.id)}
                      >
                        👁️ View Comments
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Add Comment Modal */}
      {modalOpen && (
        <div
          className="modal"
          style={{
            display: "block",
            position: "fixed",
            zIndex: 1050,
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            overflow: "auto",
            backgroundColor: "rgba(0,0,0,0.6)",
          }}
        >
          <div
            style={{
              backgroundColor: "#fff",
              margin: "10% auto",
              padding: "20px",
              borderRadius: "10px",
              width: "90%",
              maxWidth: "500px",
              position: "relative",
            }}
          >
            <h4>Add Comment</h4>
            <textarea
              className="form-control"
              rows="4"
              style={{
                zIndex: 99999,
                position: "relative",
                backgroundColor: "#fff",
                color: "#000",
              }}
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Write your comment..."
            ></textarea>
            <div className="mt-3 d-flex justify-content-end">
              <button className="btn btn-secondary me-2" onClick={closeModal}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleAddComment}>
                Submit
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Comments Modal */}
      {viewCommentsOpen && (
        <div
          className="modal"
          style={{
            display: "block",
            position: "fixed",
            zIndex: 1050,
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            overflow: "auto",
            backgroundColor: "rgba(0,0,0,0.6)",
          }}
        >
          <div
            
            style={{
              backgroundColor: "#fff",
              margin: "10% auto",
              padding: "20px",
              borderRadius: "10px",
              width: "90%",
              maxWidth: "500px",
              position: "relative",
            }}
          >
            <h4 className="mb-3">Comments</h4>
            {comments.length === 0 ? (
              <p>No comments yet.</p>
            ) : (
              <ul className="list-group">
                {comments.map((c, i) => (
                  <li key={i} className="list-group-item">
                    <strong>{c.userName}:</strong> {c.text}
                  </li>
                ))}
              </ul>
            )}
            <div className="mt-3 d-flex justify-content-end">
              <button
                className="btn btn-secondary"
                onClick={() => {
                  setViewCommentsOpen(false);
                  setComments([]);
                }}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
