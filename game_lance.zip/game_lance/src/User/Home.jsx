import { collection, onSnapshot } from "firebase/firestore";
import { useEffect, useState } from "react";
import { db } from "../Firebase";
import { Link } from "react-router-dom";
import Loader from "./Loader";

export default function Home(){

  const [data, setData] = useState([]);
        const[load,setLoad]=useState(false);
        const[display,setDisplay] = useState("block")
    
       
        useEffect(() => {
          setLoad(true)
          setDisplay("none")
          const getCategories = () => {
              const categoryRef = collection(db, "categories");
  
              const unsubscribe = onSnapshot(categoryRef, (snapshot) => {
                  const Categories = snapshot.docs.map(doc => ({
                      id: doc.id,
                      ...doc.data()
                  }));
                  setData(Categories);
              });
  
              return () => unsubscribe();
          };
  
          getCategories();
          setTimeout(() => {
            setLoad(false)
            setDisplay("block")
          }, 1000);
      }, []);
    
    return(
        <>
        <>
        {load?<Loader />:null}
  {/* Hero section */}
  <section className="hero-section" style={{display:display}}>
    <div className="">
     <div className="hs-item set-bg slider-bg" data-setbg="img/slider-1.jpg">
  <div className="hs-text">
    <div className="container">
      <h2 className="text-light">
        The Best <span>Games</span> Out There
      </h2>
      <p className="text-light">
        Discover groundbreaking titles, immersive open worlds, and thrilling gameplay
        experiences that are redefining the future of gaming. <br />
        From indie surprises to AAA legends — we cover it all.
        <br />
        Stay ahead with reviews, updates, and insider news.
      </p>
      <Link to={'/userlogin'} className="site-btn">
        Join Us
      </Link>
    </div>
  </div>
</div>

   
    </div>
  </section>
  {/* Hero section end */}
  {/* Latest news section */}
  <div className="latest-news-section" style={{display:display}}>
  <div className="ln-title">Latest News</div>
  <div className="news-ticker">
    <div className="news-ticker-contant">
      <div className="nt-item">
        <span className="new">new</span>
        Rockstar officially announces GTA VI trailer release date, breaking internet records.
      </div>
      <div className="nt-item">
        <span className="strategy">strategy</span>
        Total War: Pharaoh gets a major update with enhanced AI and battle mechanics.
      </div>
      <div className="nt-item">
        <span className="racing">racing</span>
        Forza Motorsport 2025 revealed with photorealistic graphics and new tracks.
      </div>
    </div>
  </div>
</div>

  {/* Latest news section end */}
  {/* Feature section */}
<section className="feature-section spad" style={{display:display}}>
  <div className="container">
    <div className="row">
      {/* Feature 1 */}
      <div className="col-lg-3 col-md-6 p-0">
        <div className="feature-item set-bg bg-image" style={{ backgroundImage: "url('img/features/1.jpg')" }}>
          <span className="cata new">New</span>
          <div className="fi-content text-white">
            <h5>
              <a href="#">Unreal Engine 5: A New Era of Game Development</a>
            </h5>
            <p>Explore the powerful features of UE5, including Nanite and Lumen technologies.</p>
            
          </div>
        </div>
      </div>

      {/* Feature 2 */}
      <div className="col-lg-3 col-md-6 p-0">
        <div className="feature-item set-bg" style={{ backgroundImage: "url('img/features/2.jpg')" }}>
          <span className="cata strategy">Strategy</span>
          <div className="fi-content text-white">
            <h5>
              <a href="#">Top 5 Strategy Games to Play in 2025</a>
            </h5>
            <p>From Civilization VII to Age of Empires IV, here are must-play titles for strategists.</p>
            
          </div>
        </div>
      </div>

      {/* Feature 3 */}
      <div className="col-lg-3 col-md-6 p-0">
        <div className="feature-item set-bg" style={{ backgroundImage: "url('img/features/3.jpg')" }}>
          <span className="cata new">New</span>
          <div className="fi-content text-white">
            <h5>
              <a href="#">Exploring the World of Open-World RPGs</a>
            </h5>
            <p>Discover the immersive experience of the latest RPGs with expansive storylines and worlds.</p>
           
          </div>
        </div>
      </div>

      {/* Feature 4 */}
      <div className="col-lg-3 col-md-6 p-0">
        <div className="feature-item set-bg" style={{ backgroundImage: "url('img/features/4.jpg')" }}>
          <span className="cata racing">Racing</span>
          <div className="fi-content text-white">
            <h5>
              <a href="#">Fast Lane: The Rise of Realistic Racing Sims</a>
            </h5>
            <p>Sim racing games are pushing the limits of realism with advanced physics and visuals.</p>
           
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
{/* Feature section end */}

  {/* Recent game section  */}
  <section
    className="recent-game-section spad set-bg"
    style={{backgroundImage:"url('img/recent-game-bg.png')",display:display}}
   
  >
    <div className="container">
      <div className="section-title">
       
        <h2>Our Categories</h2>
      </div>
        <div className="row text-white">
        {
            data.slice(0,4).map((el)=>(
                <>
        <div className="col-lg-3 col-md-6 p-3" >
          <div className="review-item">
           <Link to={'/category-games/'+ el.id}> <div className="review-cover set-bg" style={{backgroundImage:`url(${el.imageUrl})`}}>
            </div></Link>
            <div className="review-text">
              <h5 className="text-dark">{el.categoryName}</h5>

            </div>
          </div>
        </div>
                </>
            ))
        }
       
      </div>
    </div>
  </section>
   
 
  {/* Recent game section end */}
  {/* Tournaments section */}
  <section className="tournaments-section spad" style={{display:display}}>
    <div className="container">
      <div className="tournament-title">Tournaments</div>
      <div className="row">
        <div className="col-md-6">
          <div className="tournament-item mb-4 mb-lg-0">
            <div className="ti-notic">Premium Tournament</div>
            <div className="ti-content">
              <div
                className="ti-thumb set-bg"
               style={{backgroundImage:"url('img/tournament/1.jpg')"}}
              />
              <div className="ti-text">
                <h4>World Of WarCraft</h4>
                <ul>
                  <li>
                    <span>Tournament Beggins:</span> June 20, 2018
                  </li>
                  <li>
                    <span>Tounament Ends:</span> July 01, 2018
                  </li>
                  <li>
                    <span>Participants:</span> 10 teams
                  </li>
                  <li>
                    <span>Tournament Author:</span> Admin
                  </li>
                </ul>
                <p>
                  <span>Prizes:</span> 1st place $2000, 2nd place: $1000, 3rd
                  place: $500
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="tournament-item">
            <div className="ti-notic">Premium Tournament</div>
            <div className="ti-content">
              <div
                className="ti-thumb set-bg"
                style={{backgroundImage:"url('img/tournament/2.jpg')"}}
              />
              <div className="ti-text">
                <h4>DOOM</h4>
                <ul>
                  <li>
                    <span>Tournament Beggins:</span> June 20, 2018
                  </li>
                  <li>
                    <span>Tounament Ends:</span> July 01, 2018
                  </li>
                  <li>
                    <span>Participants:</span> 10 teams
                  </li>
                  <li>
                    <span>Tournament Author:</span> Admin
                  </li>
                </ul>
                <p>
                  <span>Prizes:</span> 1st place $2000, 2nd place: $1000, 3rd
                  place: $500
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Tournaments section bg */}
  {/* Review section */}
<section
  className="review-section spad set-bg"
  style={{ backgroundImage: "url('img/review-bg.png')",display:display }}
>
  <div className="container">
    <div className="section-title">
      <div className="cata new">new</div>
      <h2>Recent Games</h2>
    </div>
    <div className="row">
      {/* Assassin’s Creed */}
      <div className="col-lg-3 col-md-6">
        <div className="review-item">
          <div
            className="review-cover set-bg"
            style={{ backgroundImage: "url('img/review/1.jpg')" }}
          >
            <div className="score yellow">9.3</div>
          </div>
          <div className="review-text">
            <h5>Assassin’s Creed Mirage</h5>
            <p>
              A stunning return to the series' roots, blending stealth, parkour, and an immersive Baghdad setting.
            </p>
          </div>
        </div>
      </div>

      {/* Doom */}
      <div className="col-lg-3 col-md-6">
        <div className="review-item">
          <div
            className="review-cover set-bg"
            style={{ backgroundImage: "url('img/review/2.jpg')" }}
          >
            <div className="score purple">9.5</div>
          </div>
          <div className="review-text">
            <h5>DOOM Eternal</h5>
            <p>
              A relentless FPS masterpiece packed with intense action, brutal combat, and fast-paced gameplay.
            </p>
          </div>
        </div>
      </div>

      {/* Overwatch */}
      <div className="col-lg-3 col-md-6">
        <div className="review-item">
          <div
            className="review-cover set-bg"
            style={{ backgroundImage: "url('img/review/3.jpg')" }}
          >
            <div className="score green">9.1</div>
          </div>
          <div className="review-text">
            <h5>Overwatch 2</h5>
            <p>
              An action-packed hero shooter with new modes, reworked characters, and smooth team-based mechanics.
            </p>
          </div>
        </div>
      </div>

      {/* GTA */}
      <div className="col-lg-3 col-md-6">
        <div className="review-item">
          <div
            className="review-cover set-bg"
            style={{ backgroundImage: "url('img/review/4.jpg')" }}
          >
            <div className="score pink">9.7</div>
          </div>
          <div className="review-text">
            <h5>Grand Theft Auto V</h5>
            <p>
              Still reigning supreme with its expansive open world, gripping story, and endlessly fun online mode.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

  {/* Review section end */}
  {/* Footer top section */}
  <section className="footer-top-section" style={{display:display}}>
  <div className="container">
    <div className="footer-top-bg">
      <img src="img/footer-top-bg.png" alt="" />
    </div>
    <div className="row">
      {/* Footer Brand/About */}
      <div className="col-lg-4">
        <div className="footer-logo text-white">
          <img src="img/footer-logo.png" alt="GamingHub Logo" />
          <p>
            GamingHub brings you the latest in gaming news, honest reviews,
            and in-depth features from the world of console, PC, and indie games.
          </p>
        </div>
      </div>

      {/* Latest Posts */}
      <div className="col-lg-4 col-md-6">
        <div className="footer-widget mb-5 mb-md-0">
          <h4 className="fw-title">Latest Posts</h4>
          <div className="latest-blog">
            <div className="lb-item">
              <div
                className="lb-thumb set-bg"
                style={{ backgroundImage: "url('img/latest-blog/1.jpg')" }}
              />
              <div className="lb-content">
                <div className="lb-date">June 28, 2025</div>
                <p>Top 10 Indie Games You Need to Play This Year</p>
                <a href="#" className="lb-author">By Admin</a>
              </div>
            </div>
            <div className="lb-item">
              <div
                className="lb-thumb set-bg"
                style={{ backgroundImage: "url('img/latest-blog/2.jpg')" }}
              />
              <div className="lb-content">
                <div className="lb-date">June 26, 2025</div>
                <p>Cyberpunk 2077 2.1 Update Brings Major Fixes and New Features</p>
                <a href="#" className="lb-author">By Admin</a>
              </div>
            </div>
            <div className="lb-item">
              <div
                className="lb-thumb set-bg"
                style={{ backgroundImage: "url('img/latest-blog/3.jpg')" }}
              />
              <div className="lb-content">
                <div className="lb-date">June 24, 2025</div>
                <p>E3 Returns in 2025 With a Hybrid Format – What to Expect</p>
                <a href="#" className="lb-author">By Admin</a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Top Comments */}
      <div className="col-lg-4 col-md-6">
        <div className="footer-widget">
          <h4 className="fw-title">Top Comments</h4>
          <div className="top-comment">
            <div className="tc-item">
              <div
                className="tc-thumb set-bg"
                style={{ backgroundImage: "url('img/authors/1.jpg')" }}
              />
              <div className="tc-content">
                <p>
                  <a href="#">Emily Clark</a> <span>on</span> "Why Elden Ring Still Reigns Supreme"
                </p>
                <div className="tc-date">June 27, 2025</div>
              </div>
            </div>
            <div className="tc-item">
              <div
                className="tc-thumb set-bg"
                style={{ backgroundImage: "url('img/authors/2.jpg')" }}
              />
              <div className="tc-content">
                <p>
                  <a href="#">Ryan Cooper</a> <span>on</span> "Steam Next Fest: Hidden Gems Roundup"
                </p>
                <div className="tc-date">June 25, 2025</div>
              </div>
            </div>
            <div className="tc-item">
              <div
                className="tc-thumb set-bg"
                style={{ backgroundImage: "url('img/authors/3.jpg')" }}
              />
              <div className="tc-content">
                <p>
                  <a href="#">Ava Thomas</a> <span>on</span> "The Evolution of Co-op Shooters"
                </p>
                <div className="tc-date">June 23, 2025</div>
              </div>
            </div>
            <div className="tc-item">
              <div
                className="tc-thumb set-bg"
                style={{ backgroundImage: "url('img/authors/4.jpg')" }}
              />
              <div className="tc-content">
                <p>
                  <a href="#">Liam Bennett</a> <span>on</span> "Top Mods for Skyrim in 2025"
                </p>
                <div className="tc-date">June 22, 2025</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

  {/* Footer top section end */}
</>

        </>
    )
}