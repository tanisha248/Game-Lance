import { createUserWithEmailAndPassword } from "firebase/auth";
import { useEffect, useState } from "react"
import { auth, db } from "../Firebase";
import { collection, doc, getDocs, onSnapshot, setDoc, Timestamp } from "firebase/firestore";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import Loader from "./Loader";
export default function Categories(){
  const [data, setData] = useState([]);
      const[load,setLoad]=useState(false);
      const[display,setDisplay] = useState("block")
  
      
      useEffect(() => {
        setLoad(true)
        setDisplay("none")
        const getCategories = () => {
            const categoryRef = collection(db, "categories");

            const unsubscribe = onSnapshot(categoryRef, (snapshot) => {
                const Categories = snapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data()
                }));
                setData(Categories);
            });

            return () => unsubscribe();
        };

        getCategories();

        setTimeout(() => {
          setLoad(false)
          setDisplay("block")
        }, 1000);
    }, []);
  
   
  
    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('img/page-top-bg/3.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>Categories</h2>
            
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Review section */}
  {load?<Loader />:null}
  <section
    className="review-section review-dark spad set-bg"
    data-setbg="/img/review-bg-2.jpg"
    style={{display:display}}
  >
    <div className="container">
      <div className="section-title">
      </div>
      <div className="row text-white">
        {
            data.map((el)=>(
                <>
        <div className="col-lg-3 col-md-6 p-3" >
          <div className="review-item">
           <Link to={'/category-games/'+ el.id}> <div className="review-cover set-bg" style={{backgroundImage:`url(${el.imageUrl})`}}>
            </div></Link>
            <div className="review-text">
              <h5 className="text-dark">{el.categoryName}</h5>

            </div>
          </div>
        </div>
                </>
            ))
        }
       
      </div>
    </div>
  </section>
  {/* Review section end */}
</>

        </>
    )
}