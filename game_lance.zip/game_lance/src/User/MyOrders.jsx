import { createUserWithEmailAndPassword, getAuth } from "firebase/auth";
import { useEffect, useState } from "react"
import { auth, db } from "../Firebase";
import { collection, doc, getDocs, getFirestore, onSnapshot, query, setDoc, Timestamp, updateDoc, where } from "firebase/firestore";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import Loader from "./Loader";

export default function MyOrders(){
  
    const [data, setData] = useState([]);
    const[load,setLoad]=useState(true);
    const[display,setDisplay] = useState("block")
    const auth = getAuth();
    const db = getFirestore();
   const [user, setUser] = useState(null);


    
   useEffect(() => {
    setLoad(true)
    setDisplay("none")
  let unsubscribe = () => {};
  const unsubscribeAuth = auth.onAuthStateChanged((currentUser) => {
    if (currentUser) {
      setUser(currentUser);
      unsubscribe = getOrder(currentUser.uid); // save unsubscribe
    }

  });
setTimeout(() => {
  setLoad(false)
  setDisplay("block")
}, 1000);
  return () => {
    unsubscribeAuth();
    if (typeof unsubscribe === "function") unsubscribe();
  };
 
}, []);



  const getOrder = (userId) => {
  const categoryCollection = collection(db, "categories");
  const orderCollection = query(collection(db, "orders"), where("userId", "==", userId));

  // Real-time listener for categories first
  getDocs(categoryCollection).then((categoriesData) => {
    const categories = categoriesData.docs.map(doc => ({ ...doc.data(), id: doc.id }));

    // Real-time listener for orders
    const unsubscribe = onSnapshot(orderCollection, (OrderData) => {
      const Order = OrderData.docs.map(doc => ({ ...doc.data(), id: doc.id }));

      const joinedData = Order.map(orderData => {
        const categoryData = categories.find(category => category.id === orderData.categoryId);
        return {
          ...orderData,
          category: categoryData
        };
      });

      setData(joinedData);
    });

    // Optional: Return unsubscribe if you want to stop listening later
    return unsubscribe;
  }).catch((error) => {
    console.error("Error fetching data:", error);
  });
};


    const cancelOrder = async (orderId) => {
        setLoad(true);
        setDisplay("none")
        try {
            const orderDocRef = doc(db, "orders", orderId);
            await updateDoc(orderDocRef, { status: "Canceled" });
            toast.success("Order cancelled successfully!");
            setTimeout(() => {
                setLoad(false);
                setDisplay("block")
            }, 2000);
        } catch (error) {
            console.error("Error cancelling order:", error);
            toast.error("Failed to cancel the order.");
            setTimeout(() => {
                setLoad(false);
                setDisplay("block");
            }, 2000);
        }
    };


    return(
        <>
        <>
  {/* Page info section */}
  <section
    className="page-info-section set-bg"
    style={{backgroundImage:"url('/img/page-top-bg/5.jpg')"}}
  >
    <div className="pi-content">
      <div className="container">
        <div className="row">
          <div className="col-xl-5 col-lg-6 text-white">
            <h2>Order</h2>
           
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page info section */}
  {/* Page section */}
  {load?<Loader/>:null}
  <section className="page-section spad contact-page" style={{display:display}}>
    <div className="container">
     <div className="row justify-content-end">
      <div className="col-3 mb-5">
      <Link to={'/makeorder'}><button className="btn btn-outline-warning">➕ Add Order</button></Link>
      </div>
     </div>
      <div className="row">
        <div className="col-lg-12 p-5" style={{border:"3px solid black",backgroundColor:"black"}}>
          <div className="contact-form-warp table-responsive">
            <h3 className="comment-title text-center text-light">MY ORDERS</h3>
           <table class="table text-light table-bordered">
            <thead>
                <tr>
                <th scope="col">Sr No.</th>
                <th scope="col">Game Name</th>
                <th scope="col">Category</th>
                <th scope="col">Budget</th>
                <th scope="col">Deadline</th>
                <th scope="col">Platforms</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
               {data.map((el, index) => (
                                    <tr key={el.id}>
                                    <th scope="row">{index + 1}</th>
                                            <td>{el.gameName}</td>
                                           <td>{el?.category?.categoryName}</td>
                                            <td>{el.budget}</td>
                                            <td>{el.deadline}</td>
                                            <td>{el.platform}</td>
                                            <td>
                                            {el.status}
                                            </td>
                                            
                                            <td>
                                                {el.status==="Pending" ? (
                                                  <>
                                                  <button
                                                    className="btn btn-danger"
                                                    onClick={() => cancelOrder(el.id)}
                                                >
                                                    Cancel
                                                </button>
                                                  </>
                                                ):(
                                                  <>
                                                  <h6 className="text-danger">You can't perform any action</h6>
                                                  </>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
            </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Page section end */}
</>

        </>
    )
}